// Package container implements dependency injection container setup
// Provides centralized configuration for services, repositories, and handlers
// This package is responsible for wiring up all dependencies and ensuring proper lifecycle management
package container

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"io"
	"net/url"
	"os"
	"path/filepath"
	"slices"
	"strconv"
	"strings"
	"time"

	sqlite_vec "github.com/asg017/sqlite-vec-go-bindings/cgo"
	_ "github.com/duckdb/duckdb-go/v2"
	esv7 "github.com/elastic/go-elasticsearch/v7"
	"github.com/elastic/go-elasticsearch/v8"
	_ "github.com/go-sql-driver/mysql" // 给 Doris (database/sql) 注册 MySQL 协议驱动
	"github.com/milvus-io/milvus/client/v2/milvusclient"
	"github.com/neo4j/neo4j-go-driver/v6/neo4j"
	"github.com/panjf2000/ants/v2"
	"github.com/qdrant/go-client/qdrant"
	"github.com/redis/go-redis/v9"
	"go.uber.org/dig"
	"google.golang.org/grpc"
	"gorm.io/driver/postgres"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"

	"github.com/Tencent/WeKnora/internal/application/repository"
	"github.com/Tencent/WeKnora/internal/application/service"
	"github.com/Tencent/WeKnora/internal/application/service/file"
	"github.com/Tencent/WeKnora/internal/common"
	"github.com/Tencent/WeKnora/internal/config"
	"github.com/Tencent/WeKnora/internal/database"
	"github.com/Tencent/WeKnora/internal/event"
	"github.com/Tencent/WeKnora/internal/handler"
	"github.com/Tencent/WeKnora/internal/handler/session"
	"github.com/Tencent/WeKnora/internal/logger"
	"github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/approval"
	"github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/experts"
	agentruntime "github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/runtime"
	"github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/subagents"
	"github.com/Tencent/WeKnora/internal/modules/agentruntime/memory"
	"github.com/Tencent/WeKnora/internal/modules/airesource/mcp"
	"github.com/Tencent/WeKnora/internal/modules/airesource/models/chat"
	"github.com/Tencent/WeKnora/internal/modules/airesource/models/embedding"
	"github.com/Tencent/WeKnora/internal/modules/airesource/models/limiter"
	"github.com/Tencent/WeKnora/internal/modules/airesource/models/utils/ollama"
	infra_web_search "github.com/Tencent/WeKnora/internal/modules/airesource/web_search"
	repoappconn "github.com/Tencent/WeKnora/internal/modules/appconnector/repository/appconnector"
	appconnectorsvc "github.com/Tencent/WeKnora/internal/modules/appconnector/service/appconnector"
	imPkg "github.com/Tencent/WeKnora/internal/modules/channels/im"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/dingtalk"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/feishu"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/mattermost"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/qqbot"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/slack"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/telegram"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/wechat"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/wecom"
	"github.com/Tencent/WeKnora/internal/modules/channels/im/yunzhijia"
	domain "github.com/Tencent/WeKnora/internal/modules/commercial"
	commercialplatform "github.com/Tencent/WeKnora/internal/modules/commercial/commercialplatform"
	ommeter "github.com/Tencent/WeKnora/internal/modules/commercial/openmeter"
	"github.com/Tencent/WeKnora/internal/modules/commercial/payment"
	repocommercial "github.com/Tencent/WeKnora/internal/modules/commercial/repository/commercial"
	commercialsvc "github.com/Tencent/WeKnora/internal/modules/commercial/service/commercial"
	"github.com/Tencent/WeKnora/internal/modules/commercial/usage"
	chatpipeline "github.com/Tencent/WeKnora/internal/modules/conversation/chat_pipeline"
	"github.com/Tencent/WeKnora/internal/modules/craft"
	"github.com/Tencent/WeKnora/internal/modules/datasource"
	confluenceConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/confluence"
	dingtalkConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/dingtalk"
	"github.com/Tencent/WeKnora/internal/modules/datasource/connector/feishu/core"
	"github.com/Tencent/WeKnora/internal/modules/datasource/connector/feishu/drive"
	"github.com/Tencent/WeKnora/internal/modules/datasource/connector/feishu/wiki"
	gitlabConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/gitlab"
	imaConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/ima"
	notionConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/notion"
	rssConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/rss"
	yuqueConnector "github.com/Tencent/WeKnora/internal/modules/datasource/connector/yuque"
	"github.com/Tencent/WeKnora/internal/modules/execution"
	"github.com/Tencent/WeKnora/internal/modules/execution/browserskill"
	"github.com/Tencent/WeKnora/internal/modules/execution/sandbox"
	"github.com/Tencent/WeKnora/internal/modules/knowledge/docparser"
	"github.com/Tencent/WeKnora/internal/modules/knowledge/retriever"
	dorisRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/doris"
	elasticsearchRepoV7 "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/elasticsearch/v7"
	elasticsearchRepoV8 "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/elasticsearch/v8"
	milvusRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/milvus"
	neo4jRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/neo4j"
	openSearchRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/opensearch"
	postgresRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/postgres"
	qdrantRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/qdrant"
	sqliteRetrieverRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/sqlite"
	tencentVectorDBRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/tencentvectordb"
	weaviateRepo "github.com/Tencent/WeKnora/internal/modules/knowledge/retriever/weaviate"
	"github.com/Tencent/WeKnora/internal/modules/policy/storageallowlist"
	pushnotification "github.com/Tencent/WeKnora/internal/modules/workbench/notification"
	workbenchservice "github.com/Tencent/WeKnora/internal/modules/workbench/service/workbench"
	"github.com/Tencent/WeKnora/internal/modules/workbench/voice"
	"github.com/Tencent/WeKnora/internal/router"
	"github.com/Tencent/WeKnora/internal/stream"
	"github.com/Tencent/WeKnora/internal/tracing/langfuse"
	"github.com/Tencent/WeKnora/internal/types"
	"github.com/Tencent/WeKnora/internal/types/interfaces"
	secutils "github.com/Tencent/WeKnora/internal/utils"
	"github.com/tencent/vectordatabase-sdk-go/tcvectordb"
	"github.com/weaviate/weaviate-go-client/v5/weaviate"
	"github.com/weaviate/weaviate-go-client/v5/weaviate/auth"
	wgrpc "github.com/weaviate/weaviate-go-client/v5/weaviate/grpc"
)

// tenantReleaseDependencyResolver fails closed until the referenced tenant
// Skill/Subagent has a stable redistributable version source. It permits
// dependency-free Agent Releases and never invents caller-controlled locks.
type tenantReleaseDependencyResolver struct{}

func (tenantReleaseDependencyResolver) Resolve(_ context.Context, _ uint64, version types.AgentVersionSnapshot) (types.DependencyLock, error) {
	if version.Agent == nil {
		return types.DependencyLock{}, fmt.Errorf("cannot resolve dependencies for an empty agent version")
	}
	if len(version.Agent.Config.SelectedSkills) > 0 || len(version.Agent.Config.Subagents) > 0 {
		missing := make([]string, 0, len(version.Agent.Config.SelectedSkills)+len(version.Agent.Config.Subagents))
		for _, id := range version.Agent.Config.SelectedSkills {
			missing = append(missing, fmt.Sprintf("skill %q", id))
		}
		for _, id := range version.Agent.Config.Subagents {
			missing = append(missing, fmt.Sprintf("subagent %q", id))
		}
		return types.DependencyLock{}, fmt.Errorf("missing immutable redistributable dependencies: %s", strings.Join(missing, ", "))
	}
	return types.DependencyLock{Dependencies: []types.AgentReleaseDependency{}}, nil
}

// BuildContainer constructs the dependency injection container
// Registers all components, services, repositories and handlers needed by the application
// Creates a fully configured application container with proper dependency resolution
// Parameters:
//   - container: Base dig container to add dependencies to
//
// Returns:
//   - Configured container with all application dependencies registered
func BuildContainer(container *dig.Container) *dig.Container {
	ctx := context.Background()
	logger.Debugf(ctx, "[Container] Starting container initialization...")

	// Register resource cleaner for proper cleanup of resources
	must(container.Provide(NewResourceCleaner, dig.As(new(interfaces.ResourceCleaner))))

	// Core infrastructure configuration
	logger.Debugf(ctx, "[Container] Registering core infrastructure...")
	must(container.Provide(config.LoadConfig))
	must(container.Provide(initLangfuse))
	must(container.Provide(initDatabase))
	must(container.Provide(initFileService))
	must(container.Provide(initRedisClient))
	must(container.Provide(initAntsPool))

	must(container.Invoke(registerLangfuseCleanup))

	// Register goroutine pool cleanup handler
	must(container.Invoke(registerPoolCleanup))

	// Initialize retrieval engine registry for search capabilities
	logger.Debugf(ctx, "[Container] Registering retrieval engine registry...")
	must(container.Provide(initRetrieveEngineRegistry))

	// External service clients
	logger.Debugf(ctx, "[Container] Registering external service clients...")
	must(container.Provide(initDocReaderClient))
	must(container.Provide(initSemanticClient))
	must(container.Provide(docparser.NewImageResolver))
	must(container.Provide(initOllamaService))
	must(container.Provide(initNeo4jClient))
	must(container.Provide(stream.NewStreamManager))
	logger.Debugf(ctx, "[Container] Initializing DuckDB...")
	must(container.Provide(NewDuckDB))
	logger.Debugf(ctx, "[Container] DuckDB registered")

	// Data repositories layer
	logger.Debugf(ctx, "[Container] Registering repositories...")
	must(container.Provide(repository.NewTenantRepository))
	must(container.Provide(repository.NewTenantAPIKeyRepository))
	must(container.Provide(repository.NewTenantMemberRepository))
	must(container.Provide(repository.NewSemanticControlRepository))
	must(container.Provide(repository.NewSemanticModelPolicyRepository))
	must(container.Provide(repository.NewSemanticModelInvocationStore))
	must(container.Provide(func(r *repository.SemanticControlRepository) interfaces.SemanticScopeInvalidator { return r }))
	must(container.Provide(service.NewSemanticScopeService))
	must(container.Provide(func(cfg *config.Config, s *service.SemanticScopeService) *handler.SemanticInternalHandler {
		return handler.NewSemanticInternalHandler(cfg, s)
	}))
	must(container.Provide(repository.NewTenantInvitationRepository))
	must(container.Provide(repository.NewAuditLogRepository))
	must(container.Provide(repository.NewKnowledgeBaseRepository))
	must(container.Provide(repository.NewKnowledgeRepository))
	must(container.Provide(repository.NewKnowledgeSpanRepository))
	must(container.Provide(repository.NewChunkRepository))
	must(container.Provide(repository.NewKnowledgeTagRepository))
	must(container.Provide(repository.NewSessionRepository))
	must(container.Provide(repository.NewMessageRepository))
	must(container.Provide(repository.NewFeedbackRepository))
	// SP13: async query-history CSV export job store + aggregated rows.
	must(container.Provide(repository.NewQueryHistoryExportJobRepository))
	must(container.Provide(repository.NewAnalyticsRepository))
	must(container.Provide(repository.NewUsageRepository))
	// SP12 chat usage ingestion: the recorder turns finished chat turns into
	// user_usage daily buckets. A malformed WEKNORA_USAGE_RATES value disables
	// pricing (empty rates) rather than failing startup — chat must not go
	// down with the meter.
	must(container.Provide(newUsageRecorderService))
	must(container.Provide(repository.NewAgentRunStore))
	// W26: immutable artifact version rows live in the same business database
	// scope as the run store so imports and downloads share one fence.
	must(container.Provide(repository.NewArtifactVersionStore))
	must(container.Provide(repository.NewNotificationStore))
	must(container.Provide(repository.NewNotificationProviderStateStore))
	must(container.Provide(workbenchservice.NewNotificationProjector))
	must(container.Provide(workbenchservice.NewNotificationWorker))
	must(container.Provide(newMobileNotificationProvider))
	must(container.Provide(newMobileNotificationDeliveryWorker))
	must(container.Provide(repository.NewMobileExchangeStore))
	// W30: voice session rows (ownership, provider mapping, admission
	// verdict, settled usage) share the same business database scope.
	must(container.Provide(repository.NewVoiceSessionStore))
	must(container.Provide(newMobileVoiceHandler))
	// The dispatch intent/receipt log is a first-class dependency of the
	// durable worker. Keep it in the same database scope as AgentRunStore so
	// provider starts can never bypass the W20 fence.
	must(container.Provide(repository.NewExecutionDispatchStore))
	must(container.Provide(repository.NewExecutionObservationStore))
	must(container.Provide(newPaseoRemoteProvider))
	// Commercial execution-gate chain (gateway → gate → remote usage). These
	// providers must precede the craft Invoke below: dig resolves lazily at
	// Invoke time, so any provider registered after Invoke(registerCraftHTTPHandlers)
	// leaves newAgentRuntime's *RemoteUsageService missing and panics boot.
	must(container.Provide(ommeter.NewGatewayFromEnv, dig.As(new(domain.CommercialGateway))))
	// U05 execution gate: the billable outbound boundary (Begin reserves and
	// persists dispatched intent before dispatch, Finish settles trusted
	// usage). Registered only — no Invoke: arming an engine turn with it is
	// an explicit SetCommercialGate by the commercial request path, so
	// non-commercial behavior is unchanged.
	must(container.Provide(commercialsvc.NewExecutionGateService, dig.As(new(domain.ExecutionGate))))
	// W24: all remote usage settlement is constructed behind the trusted
	// gateway identity seam; callers never inject a client-reported fact.
	must(container.Provide(workbenchservice.NewRemoteUsageServiceWithDB))
	// Install the durable resource guard before any Docker client is resolved;
	// idle cleanup must fail closed when the lookup is unavailable.
	must(container.Provide(service.NewGormAgentRunResourceRepository))
	must(container.Invoke(registerAgentRunResourceProtection))
	// Resolve the runtime through this wrapper so the durable resource
	// repository is always connected to the post-claim recovery hook; the
	// wrapper also carries the W20 dispatch store and Paseo provider, engaging
	// the remote intent/receipt fence when that integration is configured.
	// *AgentRuntime must only be provided once for dig, so the bare
	// NewAgentRuntime / NewAgentRuntimeWithRemoteProvider providers stay
	// unregistered here.
	must(container.Provide(newAgentRuntime))
	must(container.Provide(repository.NewAgentRunSnapshotRepository))
	must(container.Provide(repository.NewExecutionTargetStore))
	must(container.Provide(repository.NewExecutionTargetIdentityProvider))
	must(container.Provide(NewMobileDeviceStore))
	must(container.Provide(NewMobileDeviceHandler))
	must(container.Provide(NewWorkbenchReadHandler))
	must(container.Provide(NewWorkbenchArtifactHandler))
	must(container.Provide(repository.NewWorkbenchListStore))
	must(container.Provide(NewWorkbenchListHandler))
	must(container.Provide(NewWorkbenchAdmissionCoordinator))
	must(container.Provide(NewWorkbenchStartHandler))
	must(container.Provide(NewWorkbenchInteractionStore))
	must(container.Provide(NewWorkbenchInteractionService))
	must(container.Provide(NewWorkbenchCommandHandler))
	must(container.Provide(NewWorkbenchOverviewService))
	must(container.Provide(NewWorkbenchOverviewHandler))
	must(container.Provide(NewWorkbenchInboxHandler))
	must(container.Provide(repository.NewMessageSuggestionRepository))
	must(container.Provide(repository.NewModelRepository))
	must(container.Provide(repository.NewUserRepository))
	must(container.Provide(repository.NewAuthTokenRepository))
	must(container.Provide(repository.NewSystemSettingRepository))
	must(container.Provide(neo4jRepo.NewNeo4jRepository))
	must(container.Provide(repository.NewMCPServiceRepository))
	must(container.Provide(repository.NewMCPToolApprovalRepository))
	must(container.Provide(repository.NewMCPOAuthRepository))
	must(container.Provide(repository.NewTenantSandboxConfigRepository))
	must(container.Provide(repository.NewTenantSkillRepository))
	must(container.Provide(repository.NewTenantSubagentRepository))
	must(container.Provide(repository.NewExpertInstallRepository))
	must(container.Provide(repository.NewPublishedSkillRepository))
	must(container.Provide(repository.NewPublishedExpertRepository))
	must(container.Provide(repository.NewCustomAgentRepository))
	must(container.Provide(repository.NewAgentVersionRepository))
	must(container.Provide(repository.NewAgentMarketplaceRepository))
	must(container.Provide(func(repo repository.AgentMarketplaceRepository) interfaces.AgentMarketplaceRepository { return repo }))
	must(container.Provide(repository.NewOrganizationRepository))
	must(container.Provide(repository.NewKBShareRepository))
	must(container.Provide(repository.NewAgentShareRepository))
	must(container.Provide(repository.NewEmbedChannelRepository))
	must(container.Provide(repository.NewTenantDisabledSharedAgentRepository))
	must(container.Provide(repository.NewUserResourceFavoriteRepository))
	must(container.Provide(service.NewWebSearchStateService))
	must(container.Provide(repository.NewDataSourceRepository))
	must(container.Provide(repository.NewSyncLogRepository))
	must(container.Provide(repository.NewWikiPageRepository))
	must(container.Provide(repository.NewMemoryRepository))
	must(container.Provide(repository.NewTaskPendingOpsRepository))
	must(container.Provide(repository.NewTaskDeadLetterRepository))

	// MCP manager for managing MCP client connections
	logger.Debugf(ctx, "[Container] Registering MCP manager...")
	must(container.Provide(mcp.NewMCPManager))
	must(container.Provide(mcp.NewOAuthManager))

	// Sandbox manager fallback is disabled; executable backends are resolved
	// from named workspace configurations.
	logger.Debugf(ctx, "[Container] Registering sandbox manager...")
	must(container.Provide(newSandboxManager))
	// Per-tenant sandbox backends: the resolver builds a manager per request
	// from the tenant's own configuration, falling back to the singleton above
	// for tenants that configured nothing.
	must(container.Provide(service.NewTenantSandboxConfigLoader))
	must(container.Provide(newTenantSandboxResolver))

	// Business service layer
	logger.Debugf(ctx, "[Container] Registering business services...")
	must(container.Provide(service.NewTenantService))
	must(container.Provide(service.NewTenantAPIKeyService))
	must(container.Provide(service.NewTenantMemberService))
	must(container.Provide(service.NewTenantInvitationService))
	must(container.Provide(service.NewAuditLogService))
	must(container.Provide(service.NewAuditLogRetentionRunner))
	must(container.Provide(service.NewKnowledgeBaseService))
	must(container.Provide(service.NewOrganizationService))
	must(container.Provide(service.NewKBShareService)) // KBShareService must be registered before KnowledgeService and KnowledgeTagService
	must(container.Provide(service.NewAgentShareService))
	must(container.Provide(service.NewKnowledgeService))
	must(container.Decorate(func(s interfaces.TenantMemberService, i interfaces.SemanticScopeInvalidator) interfaces.TenantMemberService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Decorate(func(s interfaces.OrganizationService, i interfaces.SemanticScopeInvalidator) interfaces.OrganizationService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Decorate(func(s interfaces.KnowledgeService, i interfaces.SemanticScopeInvalidator) interfaces.KnowledgeService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Decorate(func(s interfaces.KBShareService, i interfaces.SemanticScopeInvalidator) interfaces.KBShareService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Decorate(func(s interfaces.KnowledgeBaseService, i interfaces.SemanticScopeInvalidator) interfaces.KnowledgeBaseService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Provide(service.NewSpanTracker))
	must(container.Provide(service.NewChunkService))
	must(container.Provide(service.NewKnowledgeTagService))
	must(container.Provide(embedding.NewBatchEmbedder))
	must(container.Provide(service.NewModelService))
	must(container.Provide(service.NewDatasetService))
	must(container.Provide(service.NewEvaluationService))
	must(container.Provide(service.NewUserService))
	must(container.Decorate(func(s interfaces.TenantService, i interfaces.SemanticScopeInvalidator) interfaces.TenantService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Decorate(func(s interfaces.UserService, i interfaces.SemanticScopeInvalidator) interfaces.UserService {
		s.(interface {
			SetSemanticScopeInvalidator(interfaces.SemanticScopeInvalidator)
		}).SetSemanticScopeInvalidator(i)
		return s
	}))
	must(container.Provide(service.NewSystemSettingService))
	must(container.Provide(func(
		repo repository.TenantSandboxConfigRepository,
		agents interfaces.CustomAgentRepository,
		skills repository.TenantSkillRepository,
		files interfaces.StorageBackendResolver,
	) *service.TenantSandboxConfigService {
		return service.NewTenantSandboxConfigService(repo, agents, buildGlobalSandboxConfig(), skills, files)
	}))
	must(container.Provide(func(s *service.TenantSandboxConfigService) service.WorkspaceSandboxPolicy {
		return s
	}))
	must(container.Provide(service.NewWeKnoraCloudService))

	// Extract services - register individual extracters with names
	must(container.Provide(service.NewChunkExtractService, dig.Name("chunkExtractor")))
	must(container.Provide(service.NewDataTableSummaryService, dig.Name("dataTableSummary")))
	must(container.Provide(service.NewImageMultimodalService, dig.Name("imageMultimodal")))
	must(container.Provide(service.NewKnowledgePostProcessService, dig.Name("knowledgePostProcess")))
	must(container.Provide(service.NewKnowledgeAutoTagService, dig.Name("knowledgeAutoTag")))

	must(container.Provide(service.NewMessageService))
	must(container.Provide(service.NewFeedbackService))
	must(container.Provide(service.NewMessageSuggestionService))
	must(container.Provide(service.NewMCPServiceService))
	must(container.Provide(service.NewMCPToolApprovalService))
	must(container.Provide(service.NewCustomAgentService))
	must(container.Provide(func() interfaces.ReleaseDependencyResolver { return tenantReleaseDependencyResolver{} }))
	must(container.Provide(func(agents interfaces.CustomAgentService, versions repository.AgentVersionRepository) interfaces.AgentVersionService {
		return service.NewAgentVersionService(agents, versions)
	}))
	must(container.Provide(func(versions interfaces.AgentVersionService, resolver interfaces.ReleaseDependencyResolver, repo interfaces.AgentMarketplaceRepository) interfaces.AgentMarketplaceService {
		return service.NewAgentMarketplaceService(versions, resolver, repo, filepath.Join(experts.MarketDataRoot(), "tenant-releases"))
	}))
	must(container.Provide(handler.NewAgentVersionHandler))
	must(container.Provide(handler.NewAgentMarketplaceHandler))
	must(container.Provide(service.NewUserResourceFavoriteService))
	must(container.Provide(service.NewWikiPageService))
	must(container.Provide(service.NewWikiIngestService, dig.Name("wikiIngest")))
	must(container.Provide(service.NewWikiLintService))
	must(container.Provide(service.NewEmbedChannelService))

	// Web search service (needed by AgentService)
	logger.Debugf(ctx, "[Container] Registering web search registry and providers...")
	must(container.Provide(infra_web_search.NewRegistry))
	must(container.Invoke(registerWebSearchProviders))
	must(container.Provide(repository.NewWebSearchProviderRepository))
	must(container.Provide(repository.NewVectorStoreRepository))
	must(container.Provide(repository.NewStorageBackendRepository))
	must(container.Provide(repository.NewResourceRepository))
	must(container.Provide(repository.NewTemporaryDocumentRepository))
	must(container.Provide(service.NewResourceCatalog))
	// TenantStoreOwnership adapter used by the retriever factory functions
	// to verify that a resolved VectorStore belongs to the caller's tenant.
	must(container.Provide(retriever.NewVectorStoreRepoOwnership))
	must(container.Provide(service.NewWebSearchService))
	must(container.Provide(service.NewWebSearchProviderService))
	must(container.Provide(NewEngineFactory))
	// StoreRegistry: same instance as RetrieveEngineRegistry, exposed as StoreRegistry interface.
	// NewRetrieveEngineRegistry always returns *retriever.RetrieveEngineRegistry which implements both.
	must(container.Provide(func(r interfaces.RetrieveEngineRegistry) (interfaces.StoreRegistry, error) {
		sr, ok := r.(*retriever.RetrieveEngineRegistry)
		if !ok {
			return nil, fmt.Errorf("registry does not implement StoreRegistry")
		}
		return sr, nil
	}))
	must(container.Provide(service.NewVectorStoreService))
	must(container.Provide(service.NewStorageBackendServiceWithResources))
	must(container.Provide(func(s *service.StorageBackendService) interfaces.StorageBackendService { return s }))
	must(container.Provide(func(s *service.StorageBackendService) interfaces.StorageBackendResolver { return s }))

	// Agent service layer (requires event bus, web search service)
	// SessionService is passed as parameter to CreateAgentEngine method when creating AgentService
	logger.Debugf(ctx, "[Container] Registering event bus and agent service...")
	must(container.Provide(event.NewEventBus))
	must(container.Provide(service.NewSessionSandboxPinner))
	must(container.Provide(func(cfg *config.Config, s interfaces.MCPToolApprovalService, rdb *redis.Client) *approval.Gate {
		return approval.NewGate(cfg, &approval.Adapter{Svc: s}, rdb)
	}))
	// Expose Gate as MCPApproval interface so AgentService and others can depend on the abstraction.
	must(container.Provide(func(g *approval.Gate) approval.MCPApproval { return g }))

	// Craft delegation assembly (R05): the durable Craft store, the real
	// active-run check and the delegation service handed to the agent
	// service. CraftActiveRunsQuery is the production CraftRunActivity the
	// Craft workspace resolver assembles against (R03 nit-1) — the real
	// agent_runs query, never an always-false stub. The sandboxed OpenCode
	// dial and the pinned runtime digest are owned by the Craft runtime
	// deployment task; until it lands the executor fails closed with
	// craft.ErrUnsupported, so no builtin session and no live sub-execution
	// is affected — craft_delegate only opens for tRPC sessions that already
	// have a bound Craft workspace.
	must(container.Provide(repository.NewCraftStore))
	// R5 RunView material assembly is a separate, default-off capability. It
	// exists for downstream H3 wiring, but no local workDir is ever used as a
	// material source. Missing deployment pins leave Provider/ResolveMaterial
	// nil and preserve the unavailable behavior.
	must(container.Provide(provideCraftRunViewProductionAssembly))
	// T08 Task ACL is one persistent service instance shared through its
	// concrete API and the narrow craft.TaskAccessChecker port. Feature
	// registration is owned by the router assembly that receives this registry.
	must(container.Provide(service.NewCraftAccessService))
	must(container.Provide(craftTaskAccessChecker))
	must(container.Provide(session.NewCraftFeatureRoutes))
	must(container.Provide(service.CraftActiveRunsQuery))
	// W06 (coordinator-authorized): the executor assembly is env-driven —
	// CRAFT_OPENCODE_BASE_URL assembles the real R01 Client -> R04 Executor
	// -> CraftDelegateService chain on the local pinned serve (see
	// craft_runtime.go); without it the R05 fail-closed executor stays and
	// the default-off semantics are unchanged.
	must(container.Provide(newCraftRuntimeExecutor))
	// C02 interaction chain: production interaction store + control service +
	// reliable decision delivery (fail-closed without the opencode runtime).
	must(container.Provide(newCraftInteractionAssembly))
	must(container.Provide(service.NewCraftDelegation))

	// Craft product HTTP surface (W03): the version store (W01), the preview
	// check store + preview service (W02; the preview stays disabled until
	// its isolated https origin is configured) and the craft session service
	// behind the workbench HTTP entrance. The handlers register themselves
	// for route mounting — routes_chat.go mounts the authenticated surface,
	// router.go mounts the pre-auth preview origin. The R03 workspace
	// resolver still has no honest production dial and remains
	// uninstantiated: the executor above fails closed, which is the recorded
	// assembly boundary (craft runtime deployment task).
	must(container.Provide(repository.NewCraftVersionStore))
	must(container.Provide(repository.NewCraftPreviewCheckStore))
	must(container.Provide(newCraftPreviewService))
	must(container.Provide(newCraftSessionService))
	// C05: the recovery snapshot service rides the same env-driven local
	// runtime as the executor; without the craft dial it stays nil and the
	// snapshot/restore routes never mount (fail-closed, like the executor).
	must(container.Provide(newCraftSnapshotService))
	// C01 production assembly (coordinator-assigned C06 integration item):
	// the knowledge material build mounted with its REAL ACL ports. Without
	// the craft runtime dial the provider answers nil — fail-closed, the
	// same boundary the executor and snapshot service keep.
	must(container.Provide(newCraftKnowledgeService))
	// O03/O04 integration wiring (coordinator-assigned): the craft lifecycle
	// service (guards, tombstone, sweep), the O01 usage ledger read side and
	// the O04 usage view. See craft_lifecycle.go for the assembly details.
	must(container.Provide(newCraftLifecycleService))
	must(container.Provide(newCraftUsageService))
	must(container.Provide(newCraftUsageViewService))
	// SP3 (C-23): the craft scheduled-task store — owner-scoped recipe CRUD,
	// the due-fire CAS claim (Ruling P-1) and the run ledger. The 30s
	// dispatcher arrives in its own task; this is the durable layer it and
	// the HTTP surface build on.
	must(container.Provide(repository.NewCraftScheduledTaskRepository))
	// The scheduled-task application service (CRUD + run-now + run history)
	// over the store above; its HTTP handler registers through the
	// package-level registration routes_chat.go picks up (the Task 2 service
	// deliberately stopped before the container wiring — this is it).
	must(container.Provide(newCraftScheduledService))
	// The craft handler registration is deferred until every provider the
	// session service needs (SessionService, TemporaryDocumentService, ...)
	// is registered: dig.Invoke resolves eagerly, and W03's original position
	// above panicked at boot because those providers appear later in the
	// registration order (first observed booting the real server in W06).

	// Local browser integration (A13): one gateway manager per process,
	// validated at DI time and closed with the resource cleaner. The manager
	// is disabled (zero-value Enabled) unless BROWSERSKILL_BINARY is set, so
	// deployments without the integration boot unchanged.
	must(container.Provide(func(cleaner interfaces.ResourceCleaner, db *gorm.DB) (*browserskill.Manager, error) {
		manager := browserskill.NewManager(browserskill.NewStore(db))
		if err := manager.ValidateConfiguration(); err != nil {
			return nil, err
		}
		cleaner.RegisterWithName("BrowserSkill", func() error { manager.Close(); return nil })
		return manager, nil
	}))

	must(container.Provide(service.NewAgentService))

	// Session service (depends on agent service)
	// SessionService is created after AgentService and passes itself to AgentService.CreateAgentEngine when needed
	logger.Debugf(ctx, "[Container] Registering memory service...")
	must(container.Provide(memory.NewMemoryService))

	logger.Debugf(ctx, "[Container] Registering session service...")
	must(container.Provide(service.NewSessionService))
	must(container.Provide(service.NewTenantSkillService))
	// The member-facing half of env vars is its own service because its
	// authority is different in kind: it derives the identity from the context
	// and touches only that identity's rows.
	must(container.Provide(service.NewUserEnvService))

	// ArtifactCollector drains skill-generated files from the sandbox on
	// each agent turn (see spec at
	// docs/superpowers/specs/2026-07-10-skill-artifact-download-design.md).
	// The factory returns nil when the sandbox backend does not support
	// per-session file inspection; downstream code guards on nil.
	must(container.Provide(service.NewArtifactCollectorFromSandboxManager))

	// SandboxTerminalService opens interactive PTYs on session sandboxes for
	// the frontend terminal panel. First-use provisioning takes a sandbox
	// config ID already resolved by the WebSocket handler (own or shared agent).
	must(container.Provide(service.NewSandboxTerminalService))

	logger.Debugf(ctx, "[Container] Registering task enqueuer...")
	redisAvailable := os.Getenv("REDIS_ADDR") != ""
	if redisAvailable {
		must(container.Provide(router.NewAsyncqClient, dig.As(new(interfaces.TaskEnqueuer))))
		// Dedicated pools guarantee capacity for each stage. The shared pool
		// additionally subscribes to core/enrichment queues to provide elastic
		// borrowing while post-process and maintenance remain hard-isolated.
		must(container.Provide(router.NewCoreAsynqServer, dig.Name("coreAsynqServer")))
		must(container.Provide(router.NewPostProcessAsynqServer, dig.Name("postProcessAsynqServer")))
		must(container.Provide(router.NewEnrichmentAsynqServer, dig.Name("enrichmentAsynqServer")))
		must(container.Provide(router.NewMaintenanceAsynqServer, dig.Name("maintenanceAsynqServer")))
		must(container.Provide(router.NewSharedAsynqServer, dig.Name("sharedAsynqServer")))
		must(container.Provide(router.NewWikiAsynqServer, dig.Name("wikiAsynqServer")))
		// Asynq inspector for cancel-by-knowledge-id (best-effort
		// dequeue of pending/scheduled/retry tasks + active-task cancel).
		must(container.Provide(router.NewAsynqInspector))
		must(container.Provide(router.NewAsynqTaskInspector))
		// Install the distributed per-model chat concurrency governor. Only
		// available with Redis (the shared semaphore backend); Lite mode is
		// single-process and low-volume, so it runs ungated.
		must(container.Invoke(registerModelConcurrencyLimiter))
	} else {
		syncExec := router.NewSyncTaskExecutor()
		must(container.Provide(func() interfaces.TaskEnqueuer { return syncExec }))
		must(container.Provide(func() *router.SyncTaskExecutor { return syncExec }))
		// Lite mode: no Redis means no asynq inspector. SyncTaskExecutor
		// dispatches inline goroutines that the checkpoint-based abort
		// already handles.
		must(container.Provide(router.NewNoopTaskInspector))
		// Even without Redis, background ingestion/enrichment can burst the
		// worker pool against one provider, so install an in-process governor.
		must(container.Invoke(registerLiteModelConcurrencyLimiter))
	}
	must(container.Provide(service.NewTemporaryDocumentService))
	must(container.Invoke(startTemporaryDocumentCleanup))

	// SP13 Task 4: the Admin+ async query-history CSV export service. It
	// needs the task enqueuer registered above (asynq client or Lite sync
	// executor), so it is provided after that block; the worker body is
	// registered on both executors (router/task.go, router/sync_task.go).
	must(container.Provide(service.NewQueryHistoryExportService))

	// Chat pipeline components for processing chat requests
	logger.Debugf(ctx, "[Container] Registering chat pipeline plugins...")

	// Data source sync framework
	logger.Debugf(ctx, "[Container] Registering data source sync framework...")
	must(container.Provide(initConnectorRegistry))
	must(container.Provide(datasource.NewScheduler))
	must(container.Provide(service.NewDataSourceService))
	// SP2-a Task 5: install the queue inspector before the scheduler starts so
	// the very first delete/pause can already hard-cancel queued syncs.
	must(container.Invoke(injectDataSourceTaskInspector))
	must(container.Invoke(startDataSourceScheduler))
	logger.Debugf(ctx, "[Container] Data source sync framework registered")
	must(container.Invoke(startAuditLogRetention))
	logger.Debugf(ctx, "[Container] Audit log retention runner registered")
	must(container.Provide(service.NewHousekeepingService))
	must(container.Invoke(startHousekeepingService))
	logger.Debugf(ctx, "[Container] Knowledge housekeeping runner registered")
	must(container.Provide(chatpipeline.NewEventManager))
	must(container.Invoke(chatpipeline.NewPluginSearch))
	must(container.Invoke(chatpipeline.NewPluginRerank))
	must(container.Invoke(chatpipeline.NewPluginWebFetch))
	must(container.Invoke(chatpipeline.NewPluginMerge))
	must(container.Invoke(chatpipeline.NewPluginDataAnalysis))
	must(container.Invoke(chatpipeline.NewPluginIntoChatMessage))
	must(container.Invoke(chatpipeline.NewPluginChatCompletion))
	must(container.Invoke(chatpipeline.NewPluginChatCompletionStream))
	must(container.Invoke(chatpipeline.NewPluginFilterTopK))
	must(container.Invoke(chatpipeline.NewPluginQueryUnderstand))
	must(container.Invoke(chatpipeline.NewPluginLoadHistory))
	must(container.Invoke(chatpipeline.NewPluginMemoryRecall))
	must(container.Invoke(chatpipeline.NewPluginExtractEntity))
	must(container.Invoke(chatpipeline.NewPluginSearchEntity))
	must(container.Invoke(chatpipeline.NewPluginSearchParallel))
	must(container.Invoke(chatpipeline.NewPluginWikiBoost))
	must(container.Invoke(chatpipeline.NewPluginMemoryAffinity))
	logger.Debugf(ctx, "[Container] Chat pipeline plugins registered")
	// Craft handler registration now that its full dependency set exists
	// (W03's eager Invoke position is moved here — see the craft block above).
	must(container.Invoke(registerCraftHTTPHandlers))
	// SP3 (C-23): the scheduled-task HTTP surface (needs only the store
	// provider, so it resolves alongside the craft handlers).
	must(container.Invoke(registerCraftScheduledHTTPHandlers))
	// W26: the versioned artifact download entry mounts on the sessions route
	// table through the package-level registration (routes_chat.go).
	must(container.Invoke(registerArtifactVersionHTTPHandlers))
	// W27: the isolated artifact preview handler mounts its issue route on
	// the sessions table (routes_chat.go) and its redemption route before
	// the global Auth middleware (router.go), both via the package-level
	// registration.
	must(container.Invoke(registerArtifactPreviewHTTPHandlers))
	// C02: interaction decide surface + outbox redelivery sweep, plus the
	// post-construction registrar wiring that breaks the provider cycle
	// (see wireCraftInteractionRegistrar).
	must(container.Invoke(wireCraftInteractionRegistrar))
	must(container.Invoke(registerCraftInteractionHTTPHandlers))
	must(container.Invoke(startCraftDecisionDelivery))
	// C01 production assembly validation (nil without the runtime dial).
	must(container.Invoke(validateCraftKnowledgeAssembly))
	// O04: the usage view handler rides the craft session route table.
	must(container.Invoke(registerCraftUsageHTTPHandlers))
	// O03 hard wiring: delegation/restore guards + the periodic reclamation
	// sweep (default ON; CRAFT_LIFECYCLE_SWEEP_DISABLED=true turns it off).
	must(container.Invoke(wireCraftLifecycleIntegration))
	// W33 cleanup worker uses the repository-owned observation source. It
	// remains fail-closed for W26 file/blob/backup deletion until that adapter
	// is registered.
	must(container.Invoke(func(store *repository.AgentRunStore, files interfaces.FileService, cleaner interfaces.ResourceCleaner) {
		store.SetCleanupFilePurger(repository.NewFileCleanupPurger(store.DB(), files))
		StartExecutionCleanupSweep(store, cleaner)
	}))

	// TenantSkillService is provided next to SessionService (handlers need
	// it), but Invoke constructs the whole chain. SessionService needs
	// *chatpipeline.EventManager, which only exists after the pipeline
	// block above — starting the reaper any earlier panics.
	must(container.Invoke(startTenantSkillReaper))
	logger.Debugf(ctx, "[Container] Tenant skill reaper registered")

	// HTTP handlers layer
	logger.Debugf(ctx, "[Container] Registering HTTP handlers...")
	must(container.Provide(handler.NewTenantHandler))
	must(container.Provide(handler.NewTenantMemberHandler))
	must(container.Provide(handler.NewTenantInvitationHandler))
	must(container.Provide(handler.NewAuditLogHandler))
	must(container.Provide(handler.NewKnowledgeBaseHandler))
	must(container.Provide(service.NewUnavailableSemanticModelPolicyService))
	// A03's gateway is assembled even before pricing administration is wired.
	// Its nil immutable-rate resolver deliberately makes every invocation deny
	// before model resolution; it is never a permissive production fallback.
	must(container.Provide(newUnavailableSemanticModelGateway))
	must(container.Provide(handler.NewSemanticModelPolicyHandler))
	must(container.Provide(handler.NewKnowledgeHandler))
	must(container.Provide(handler.NewChunkHandler))
	must(container.Provide(handler.NewFAQHandler))
	must(container.Provide(handler.NewTagHandler))
	// Session fork (A11) + pinned session sandbox (A17): the runner, ID
	// lookup, and fork snapshot port resolve the session's pinned manager at
	// request time; a nil pin keeps sandbox-carrying forks degrading instead
	// of failing (message-only forks still copy history + lineage).
	must(container.Provide(newPinnedSessionSandbox))
	must(container.Provide(newSessionForkService))
	must(container.Provide(newWorkspaceCheckpointer))
	must(container.Provide(newSandboxIDLookup))
	must(container.Provide(session.NewHandler))
	must(container.Provide(handler.NewMessageHandler))
	must(container.Provide(handler.NewFeedbackHandler))
	must(container.Provide(handler.NewAnalyticsHandler))
	must(container.Provide(handler.NewUsageHandler))
	must(container.Provide(handler.NewMessageSuggestionHandler))
	must(container.Provide(handler.NewModelHandler))
	must(container.Provide(handler.NewSandboxConfigHandler))
	must(container.Provide(handler.NewExecutionTargetHandler))
	must(container.Provide(repository.NewPersonalTargetProvisioner))
	must(container.Provide(execution.NewRegistrationService))
	must(container.Provide(handler.NewExecutionRegistrationHandler))
	must(container.Provide(func(
		s *service.TenantSkillService, streams interfaces.StreamManager,
	) *handler.SandboxSkillHandler {
		return handler.NewSandboxSkillHandler(s, streams)
	}))
	must(container.Provide(handler.NewMeEnvVarHandler))
	must(container.Provide(handler.NewEvaluationHandler))
	must(container.Provide(handler.NewInitializationHandler))
	must(container.Provide(handler.NewAuthHandler))
	must(container.Invoke(func(h *handler.AuthHandler, store *repository.MobileExchangeStore) {
		h.SetMobileExchangeStore(store)
	}))
	must(container.Provide(handler.NewSystemHandler))
	must(container.Provide(handler.NewMCPServiceHandler))
	must(container.Provide(handler.NewMCPCredentialsHandler))
	must(container.Provide(handler.NewMCPOAuthHandler))
	must(container.Provide(handler.NewModelCredentialsHandler))
	must(container.Provide(handler.NewWebSearchProviderCredentialsHandler))
	must(container.Provide(handler.NewDataSourceCredentialsHandler))
	must(container.Provide(handler.NewWebSearchHandler))
	must(container.Provide(handler.NewWebSearchProviderHandler))
	must(container.Provide(handler.NewVectorStoreHandler))
	must(container.Provide(handler.NewStorageBackendHandler))
	must(container.Provide(handler.NewCustomAgentHandler))
	must(container.Provide(handler.NewPersonaHandler))
	// Expert-template API (M2): the real catalog (lazy builtin scan), agent
	// creation through the shared CustomAgentService, and the production
	// bundled-skill resolver — installs go through the tenant skill service,
	// installed-skill lookups through the tenant skill repository (the same
	// lister the session path uses). Since M4 the catalog is builtin ∪ the
	// tenant's market installs (builtin precedence on ID collision): the
	// source scans <LOCAL_STORAGE_BASE_DIR>/expert-market/<tenant>/, the
	// trees MaterializeSkillset + WriteMaterializedExpert produce. The
	// service itself is provided as the interface so the skill-market
	// handler composes with the SAME instance the expert routes serve.
	must(container.Provide(func(
		agents interfaces.CustomAgentService,
		tenantSkills *service.TenantSkillService,
		skillRepo repository.TenantSkillRepository,
	) interfaces.ExpertService {
		resolver := service.NewBundledSkillResolver(tenantSkills, skillRepo)
		return service.NewExpertServiceWithSource(
			experts.LoadBuiltinExperts, agents, resolver,
			service.NewMarketExpertSource(experts.MarketDataRoot()))
	}))
	must(container.Provide(handler.NewExpertHandler))
	// Sub-agent catalog API (M3): the real builtin library (lazy scan, shared
	// read-only catalog — the same loading model the delegate gate uses),
	// agent persistence through the shared CustomAgentService (the persona
	// Apply pattern), and installed-role rows through the tenant subagent
	// repository.
	must(container.Provide(func(
		agents interfaces.CustomAgentService,
		store repository.TenantSubagentRepository,
	) *handler.SubagentHandler {
		subagentSvc := service.NewSubagentService(subagents.LoadBuiltinSubagents, agents, store)
		return handler.NewSubagentHandler(subagentSvc)
	}))
	must(container.Provide(handler.NewUserResourceFavoriteHandler))
	must(container.Provide(func(s *service.TenantSkillService) *handler.SkillHandler {
		return handler.NewSkillHandler(s, s)
	}))
	// Skill market API (M4): the cached SkillHub client from the
	// skillhub_market config section (stale-tolerant listings, cache-bypassed
	// downloads), skill installs through the tenant skill service's catalog
	// pipeline, skillset installs composing with the shared ExpertService
	// above and the expert install ledger.
	must(container.Provide(func(
		cfg *config.Config,
		tenantSkills *service.TenantSkillService,
		expertSvc interfaces.ExpertService,
		installs repository.ExpertInstallRepository,
	) (*handler.SkillMarketHandler, error) {
		marketSvc, err := service.NewSkillMarketServiceFromConfig(cfg, tenantSkills, expertSvc, installs)
		if err != nil {
			return nil, err
		}
		return handler.NewSkillMarketHandler(marketSvc), nil
	}))
	// Tenant-internal skill market API (M4): publish rows flag catalog
	// definitions as market-visible to every member of the SAME workspace;
	// installs compose with the shared TenantSkillService catalog pipeline,
	// reads go through the tenant skill repository and publisher names
	// resolve through the user repository.
	must(container.Provide(func(
		tenantSkills *service.TenantSkillService,
		skillsRepo repository.TenantSkillRepository,
		published repository.PublishedSkillRepository,
		users interfaces.UserRepository,
	) *handler.TenantSkillMarketHandler {
		marketSvc := service.NewTenantSkillMarketService(published, skillsRepo, tenantSkills, users)
		return handler.NewTenantSkillMarketHandler(marketSvc)
	}))
	// Tenant-internal expert market API (M4): publishing an agent exports an
	// immutable materialized-expert snapshot under the tenant's
	// published-experts root; installs seed the shared ExpertService's
	// installed-experts root from the snapshot, record the expert install
	// ledger row and compose with the SAME ExpertService instance the
	// expert routes serve.
	must(container.Provide(func(
		agents interfaces.CustomAgentService,
		published repository.PublishedExpertRepository,
		installs repository.ExpertInstallRepository,
		expertSvc interfaces.ExpertService,
		users interfaces.UserRepository,
	) *handler.TenantExpertMarketHandler {
		marketSvc := service.NewTenantExpertMarketService(
			agents, published, installs, expertSvc, users,
			experts.PublishedDataRoot(), experts.MarketDataRoot())
		return handler.NewTenantExpertMarketHandler(marketSvc)
	}))
	must(container.Provide(handler.NewOrganizationHandler))
	must(container.Provide(handler.NewMemoryHandler))

	// Data source handler
	must(container.Provide(handler.NewDataSourceHandler))
	// Wiki page handler
	must(container.Provide(handler.NewWikiPageHandler))
	// IM integration
	logger.Debugf(ctx, "[Container] Registering IM integration...")
	must(container.Provide(imPkg.NewService))
	must(container.Invoke(registerIMService))
	must(container.Provide(handler.NewIMHandler))
	must(container.Provide(handler.NewEmbedChannelHandler))
	must(container.Provide(handler.NewWeKnoraCloudHandler))
	must(container.Provide(handler.NewCommercialHandler))
	// T05 Commercial Platform seam (#77): the deep provider-neutral port
	// behind the frozen commercial.CommercialPlatform interface (readiness
	// snapshot first; command/reconcile families stay frozen and fail
	// closed). Registered NEXT TO the commercial handler on purpose — away
	// from the pre-craft-Invoke provider block around the OpenMeter gateway
	// (see the ordering comment there): nothing inside the craft runtime
	// resolves this interface, so a later registration cannot strand the
	// craft Invoke. Adapter selection is env-driven
	// (WEKNORA_COMMERCIAL_PLATFORM_*): unset stays legal as blocked-env and
	// the readiness read fails closed; an unknown provider fails startup
	// instead of silently falling back. The legacy OpenMeter gateway above
	// keeps its own registration untouched (removal is #105).
	must(container.Provide(commercialplatform.NewPlatformFromEnv, dig.As(new(domain.CommercialPlatform))))
	must(container.Invoke(func(h *handler.CommercialHandler, p domain.CommercialPlatform) {
		h.SetCommercialPlatform(p)
	}))
	// T06 (#78) billing account service: the lazy ensure-on-first-billing-
	// access flow behind GET /commercial/account (tenant → exactly one
	// authority customer under the deterministic identity). Placed IMMEDIATELY
	// after the platform Invoke above, on purpose — the same ordering-trap
	// rule applies: away from the pre-craft-Invoke provider block (see the
	// comment there). The service consumes the same seam registration; a
	// pending account never blocks space functions (fail-closed posture).
	must(container.Provide(commercialsvc.NewBillingAccountService))
	must(container.Invoke(func(h *handler.CommercialHandler, s *commercialsvc.BillingAccountService) {
		h.SetBillingAccountService(s)
	}))
	// T07 (#79): the plan-version lifecycle service (draft → six-axis
	// validate → idempotent publish through the seam above). Registered in
	// the SAME block, away from the pre-craft-Invoke provider block around
	// the OpenMeter gateway (the ordering trap documented there). A nil
	// platform from empty env stays legal: drafts and validation work,
	// publish fails closed unconfigured (blocked-env).
	must(container.Provide(commercialsvc.NewPlanVersionService))
	must(container.Invoke(func(h *handler.CommercialHandler, s *commercialsvc.PlanVersionService) {
		h.SetPlanVersionService(s)
	}))
	// T08 (#80): the lazy Base-Plan benefits chain (seed → account →
	// subscription → monthly credits → projection) behind the benefits
	// section of GET /commercial/account, plus the commercial growth gate
	// (ResourceQuotaGuard) wired into the member and knowledge growth
	// paths. Registered in the SAME block, away from the pre-craft-Invoke
	// provider block (the ordering trap documented there). The guard is
	// fail-open BY CONSTRUCTION: quotas bite only where a projection wrote
	// a hard_limit — an unprojected dimension (blocked-env, Lago outage,
	// unconfigured platform) carries NULL limits and every reserve passes;
	// a pending chain never locks a space out of its own functions.
	must(container.Provide(commercialsvc.NewBenefitsService))
	must(container.Invoke(func(
		h *handler.CommercialHandler,
		benefits *commercialsvc.BenefitsService,
		memberHandler *handler.TenantMemberHandler,
		knowledgeSvc interfaces.KnowledgeService,
		db *gorm.DB,
	) {
		h.SetBenefitsService(benefits)
		guard := commercialsvc.NewQuotaGuard(db)
		memberHandler.SetQuotaGuard(guard)
		if ks, ok := knowledgeSvc.(service.QuotaGuardSetter); ok && ks != nil {
			ks.SetResourceQuotaGuard(guard)
		}
	}))
	// W04/A02/A07/A03 app-connector HTTP surface: four single-lifecycle
	// handlers (installations, connections incl. OAuth, sync status,
	// actions), each owning its routes and write gate.
	must(container.Provide(handler.NewAppInstallationHandler))
	must(container.Provide(handler.NewAppConnectionHandler))
	must(container.Provide(handler.NewAppSyncHandler))
	must(container.Provide(handler.NewAppActionHandler))
	// Commercial fulfillment: the V03-selected gateway (family official_v3;
	// unconfigured env stays legal as blocked-env) and the background worker
	// that drains paid orders' fulfillment outbox events into benefits.
	// (The gateway/execution-gate/remote-usage providers this drains through
	// are registered earlier, before the craft Invoke that first resolves
	// newAgentRuntime.)
	must(container.Provide(commercialsvc.NewFulfillmentService))
	must(container.Invoke(startCommercialFulfillment))
	// A03 action approval pipeline: the persisted action store and the
	// dispatch-time credential guard (A02) are always constructed; the U05
	// execution gate above arms budget reservation. The provider-specific
	// dispatcher/unknown-resolver adapters stay nil out of the box — Execute
	// then reports an explicit dispatch-unconfigured error instead of
	// fabricating an outbound outcome. The handler is armed explicitly so
	// /apps/actions prepare/approve/execute/get stop failing closed with 501.
	must(container.Provide(repoappconn.NewActionStore, dig.As(new(appconnectorsvc.ActionStoreSource))))
	must(container.Provide(repository.NewMCPOAuthBindingStore, dig.As(new(appconnectorsvc.ConnectionCredentialSource))))
	// R11 carry (T07): the interim permission-only NewSubjectGuard(src) is
	// replaced by the FULL subject guard - the real OC store as the binding
	// source and the installation catalog as the state source, so OC binding
	// validation and install-active checks go live. No space-grant store
	// exists yet, so space connections keep failing closed (the authorizer's
	// nil-grant semantics), which only tightens the interim behavior.
	must(container.Provide(repoappconn.NewOCStore))
	must(container.Provide(repoappconn.NewInstallationStore))
	must(container.Provide(func(src appconnectorsvc.ConnectionCredentialSource,
		installs *repoappconn.InstallationStore, oc *repoappconn.OCStore,
	) appconnectorsvc.A02Guard {
		return appconnectorsvc.NewOCSubjectGuard(src, appconnectorsvc.NewInstallationStateSource(installs), nil, oc)
	}))
	// T13 open-connector product wiring (open_connector.go). The
	// ActionService is built THROUGH PrepareOpenConnector/NewOCArmedActionService
	// (the F-1 production constructor composes wiring and service) so the T10-F-3
	// mandate is enforced at construction: a real dispatcher never exists
	// without the durable claim store and the slot limiter, and
	// dispatcher-without-claims is a STARTUP FAILURE. Disabled by default:
	// the nil dispatcher IS the explicit refusing dispatcher (Execute fails
	// closed before consuming anything; the edge maps 503). Enabled-but-
	// incomplete env config also fails startup — no default-connection
	// fallback. The API process never sees the runtime ADMIN secret: it
	// only reads back the version-scoped RESTRICTED tokens the control
	// worker minted (shared secret sink).
	must(container.Provide(newOCArmedActionService))
	must(container.Provide(newOCProductServices))
	must(container.Invoke(func(h *handler.AppActionHandler, s *appconnectorsvc.ActionService) {
		h.SetActionService(s)
	}))
	must(container.Invoke(func(h *handler.AppActionHandler, p *appconnectorsvc.OCPreparer) {
		h.SetOCPreparer(p)
	}))
	must(container.Invoke(func(h *handler.AppActionHandler, s *appconnectorsvc.OCConnectionService) {
		h.SetOCConnectionService(s)
	}))
	must(container.Invoke(startOCRecoveryRunner))
	// A02 app OAuth registrations for the first-batch providers. Client
	// registrations come from env (WEKNORA_APP_OAUTH_<APP>_CLIENT_ID / _SECRET);
	// an app left unregistered fails closed at CreateConnection with an
	// explicit 501 instead of minting an unusable connection.
	must(container.Invoke(func(h *handler.AppConnectionHandler) {
		providers := handler.DefaultAppOAuthProviderConfigs()
		for appID := range providers {
			prefix := "WEKNORA_APP_OAUTH_" + strings.ToUpper(appID) + "_"
			providers[appID] = handler.AppOAuthProviderConfig{
				AuthorizeURL: providers[appID].AuthorizeURL,
				TokenURL:     providers[appID].TokenURL,
				ClientID:     os.Getenv(prefix + "CLIENT_ID"),
				ClientSecret: os.Getenv(prefix + "CLIENT_SECRET"),
			}
		}
		h.SetAppOAuthProviders(providers)
	}))
	// P02 order pipeline: quote, order and payment status recovery. Channel
	// adapters arrive from env when configured (WEKNORA_ALIPAY_* /
	// WEKNORA_WECHAT_*); an empty map stays legal (blocked-env) — checkout
	// then fails with an explicit unconfigured error while quoting and
	// ordering still work against the database. A partially configured
	// channel fails construction and therefore startup.
	must(container.Provide(payment.ProvidersFromEnv))
	must(container.Provide(commercialsvc.NewOrderService))
	must(container.Invoke(func(h *handler.CommercialHandler, s *commercialsvc.OrderService) {
		h.SetOrderService(s)
	}))
	// Provider payment callbacks share the same channel adapters: the
	// router injects this handler into RegisterCommercialRoutes so a
	// configured channel's notifications verify, confirm their order and
	// drive fulfillment instead of answering 503 with nothing persisted.
	must(container.Provide(handler.NewPaymentCallbacksHandler))
	// O01 rollout recovery: categorized recovery queue plus audited
	// replay of pause-safe operations, gated by the commercial rollout
	// config switches (safe-on defaults). Registered only — the
	// platform-operator capability check stays unset until OPS auth
	// wiring lands, so Replay fails closed out of the box.
	must(container.Provide(commercialsvc.NewRecoveryService))
	logger.Debugf(ctx, "[Container] HTTP handlers registered")

	// Wire the chat package's local image resolver so multimodal chat can read
	// local:// images that live under a tenant's configured storage PathPrefix
	// (which is not encoded in the local:// URL).
	must(container.Invoke(registerChatLocalImageResolver))

	// O03 wiring: the craft tombstone at the session-deletion entrance (the
	// Handler is fully constructible here — the router below resolves it).
	must(container.Invoke(registerCraftAccessFeature))
	must(container.Invoke(registerCraftInputFeature))
	must(container.Invoke(wireCraftSessionTombstone))

	// Router configuration
	logger.Debugf(ctx, "[Container] Registering router and starting task server...")
	must(container.Provide(router.NewRouter))
	if redisAvailable {
		must(container.Invoke(router.RunAsynqServer))
	} else {
		must(container.Invoke(router.RegisterSyncHandlers))
	}
	// Wiki operation rows are durable, while their wake-up triggers may be
	// lost across a process restart (always in Lite mode, and in Redis mode if
	// persistence succeeded immediately before trigger enqueue failed). Re-arm
	// them only after the matching handlers are ready.
	must(container.Invoke(recoverPendingWikiTasks))

	logger.Infof(ctx, "[Container] Container initialization completed successfully")
	return container
}

func newUnavailableSemanticModelGateway(
	cfg *config.Config,
	models interfaces.ModelService,
	scope *service.SemanticScopeService,
	policy *service.SemanticModelPolicyService,
	invocations *repository.SemanticModelInvocationStore,
	budget *repocommercial.BudgetStore,
	gate domain.ExecutionGate,
) *service.SemanticModelGateway {
	issuer := service.NewSemanticModelCapabilityIssuer(cfg.Semantic, scope, policy, nil, budget, invocations)
	return service.NewSemanticModelGateway(issuer, models, scope, service.NewSemanticModelBudgetAdapter(budget, gate, nil), invocations)
}

// newMobileNotificationProvider keeps push delivery behind a single
// deployment-configured HTTP gateway. An empty endpoint is valid during local
// development: the worker remains durable and fail-closed until the gateway
// is configured.
func newMobileNotificationProvider(cfg *config.Config, devices *repository.MobileDeviceStore) workbenchservice.NotificationProvider {
	endpoint := strings.TrimSpace(os.Getenv("MOBILE_NOTIFICATION_PROVIDER_URL"))
	providerKind := strings.TrimSpace(os.Getenv("MOBILE_NOTIFICATION_PROVIDER"))
	accessToken := strings.TrimSpace(os.Getenv("MOBILE_NOTIFICATION_ACCESS_TOKEN"))
	if endpoint == "" && cfg != nil && cfg.MobileNotification != nil {
		endpoint = strings.TrimSpace(cfg.MobileNotification.ProviderURL)
	}
	if providerKind == "" && cfg != nil && cfg.MobileNotification != nil {
		providerKind = strings.TrimSpace(cfg.MobileNotification.Provider)
		if accessToken == "" {
			accessToken = strings.TrimSpace(cfg.MobileNotification.AccessToken)
		}
	}
	if strings.EqualFold(providerKind, "expo") {
		return workbenchservice.NewPushNotificationProvider(pushnotification.NewExpoProvider(endpoint, accessToken), func(ctx context.Context, d repository.NotificationDelivery) (string, error) {
			if devices == nil {
				return "", errors.New("mobile_device_store_unavailable")
			}
			registration, err := devices.GetActiveForTenant(ctx, d.Intent.TenantID, d.Intent.OwnerID, d.Intent.DeviceID)
			if err != nil {
				return "", err
			}
			key := secutils.GetAESKey()
			if len(key) != 32 {
				return "", errors.New("mobile_device_token_decryption_not_configured")
			}
			return secutils.DecryptAESGCM(registration.TokenCiphertext, key)
		})
	}
	if providerKind != "" && !strings.EqualFold(providerKind, "gateway") && !strings.EqualFold(providerKind, "http") {
		return workbenchservice.NewHTTPNotificationProvider("")
	}
	// The gateway is the safe default and intentionally receives only the
	// scoped device identity. Unknown modes fail closed rather than silently
	// selecting a different vendor.
	return workbenchservice.NewHTTPNotificationProvider(endpoint)
}

func newMobileNotificationDeliveryWorker(store *repository.NotificationStore, provider workbenchservice.NotificationProvider, devices *repository.MobileDeviceStore, health *repository.NotificationProviderStateStore) *workbenchservice.NotificationDeliveryWorker {
	return workbenchservice.NewNotificationDeliveryWorkerWithHealth(store, provider, "mobile-notification-delivery", devices, health, "mobile")
}

// registerChatLocalImageResolver wires the chat package's LocalImageResolver
// hook. Stored local:// URLs are relative to the resolved storage base dir and
// do NOT encode the owning tenant's configured PathPrefix, so resolving them to
// disk bytes requires rebuilding the FileService from that tenant's storage
// config. The owning tenant is parsed from the URL's first path segment, which
// correctly handles cross-tenant shared resources (e.g. shared KB images).
func registerChatLocalImageResolver(
	tenantRepo interfaces.TenantRepository,
	storageResolver interfaces.StorageBackendResolver,
	resourceCatalog interfaces.ResourceCatalog,
) {
	chat.LocalImageResolver = func(storageURL string) ([]byte, bool) {
		ctx := context.Background()
		physicalPath, resource, err := resourceCatalog.ResolvePath(ctx, storageURL)
		if err != nil {
			return nil, false
		}
		tenantID := secutils.ParseTenantIDFromStoragePath(physicalPath)
		if resource != nil {
			tenantID = resource.TenantID
		}
		if tenantID == 0 {
			return nil, false
		}
		tenant, err := tenantRepo.GetTenantByID(ctx, tenantID)
		if err != nil || tenant == nil {
			return nil, false
		}
		baseDir := strings.TrimSpace(os.Getenv("LOCAL_STORAGE_BASE_DIR"))
		backendID, inner, scoped := types.ParseStorageBackendPath(physicalPath)
		if resource != nil && resource.StorageBackendID != "" {
			backendID = resource.StorageBackendID
		}
		providerPath := physicalPath
		if scoped {
			providerPath = inner
		}
		provider := types.ParseProviderScheme(providerPath)
		if provider == "" {
			provider = "local"
		}
		fileSvc, _, err := storageResolver.ResolveFileService(ctx, tenant, backendID, provider, baseDir)
		if err != nil {
			return nil, false
		}
		rc, err := fileSvc.GetFile(ctx, physicalPath)
		if err != nil {
			return nil, false
		}
		defer rc.Close()
		data, err := io.ReadAll(rc)
		if err != nil {
			return nil, false
		}
		return data, true
	}
}

// must is a helper function for error handling
// Panics if the error is not nil, useful for configuration steps that must succeed
// Parameters:
//   - err: Error to check
func must(err error) {
	if err != nil {
		panic(err)
	}
}

// initLangfuse initializes the Langfuse ingestion client.
// Configuration is read from LANGFUSE_* environment variables (see
// docs/langfuse.md). Returns a disabled manager if credentials are absent —
// never an error — so deployments that don't use Langfuse are unaffected.
func initLangfuse() (*langfuse.Manager, error) {
	cfg := langfuse.LoadConfigFromEnv()
	return langfuse.Init(cfg)
}

// defaultModelMaxConcurrency is the per-model cap on concurrent background
// (ingestion/enrichment) chat calls when WEKNORA_MODEL_MAX_CONCURRENCY /
// model.max_concurrency is unset. summary / question / graph enrichment all
// share the same model, so this bounds their combined pressure on one provider
// across every replica. Interactive chat is never gated.
const defaultModelMaxConcurrency = 32

// resolveModelMaxConcurrency reads the per-model background concurrency limit
// from system settings / env, defaulting to defaultModelMaxConcurrency when
// unset. A configured value of 0 (or negative) is honoured and disables the
// governor — that is the supported way to turn throttling off via config/env.
func resolveModelMaxConcurrency(ss interfaces.SystemSettingService) int {
	if ss == nil {
		return defaultModelMaxConcurrency
	}
	return int(ss.GetInt(context.Background(), "model.max_concurrency",
		"WEKNORA_MODEL_MAX_CONCURRENCY", int64(defaultModelMaxConcurrency)))
}

// registerModelConcurrencyLimiter builds the Redis-backed per-model background
// concurrency governor (chat + vlm) and installs it. Only available with Redis
// (the shared semaphore backend); Lite mode uses registerLiteModelConcurrencyLimiter.
func registerModelConcurrencyLimiter(rdb *redis.Client, ss interfaces.SystemSettingService) {
	limit := resolveModelMaxConcurrency(ss)
	limiter.SetGovernor(limiter.NewRedisLimiter(rdb), limit)
	if limit <= 0 {
		logger.Infof(context.Background(),
			"[ModelLimiter] background concurrency governor DISABLED (model.max_concurrency<=0)")
		return
	}
	logger.Infof(context.Background(),
		"[ModelLimiter] background model concurrency governed per-model, limit=%d (distributed via redis)", limit)
}

// registerLiteModelConcurrencyLimiter installs an in-process per-model governor
// for Lite mode (no Redis). Lite runs a single process, so an in-process
// semaphore is sufficient to keep a background ingestion storm from bursting
// the whole worker pool against one provider.
func registerLiteModelConcurrencyLimiter(ss interfaces.SystemSettingService) {
	limit := resolveModelMaxConcurrency(ss)
	limiter.SetGovernor(limiter.NewLocalLimiter(), limit)
	if limit <= 0 {
		logger.Infof(context.Background(),
			"[ModelLimiter] background concurrency governor DISABLED (model.max_concurrency<=0)")
		return
	}
	logger.Infof(context.Background(),
		"[ModelLimiter] background model concurrency governed per-model, limit=%d (in-process, lite mode)", limit)
}

func initRedisClient() (*redis.Client, error) {
	redisAddr := os.Getenv("REDIS_ADDR")
	if redisAddr == "" {
		logger.Infof(context.Background(), "[Redis] No REDIS_ADDR configured, Redis disabled (Lite mode)")
		return nil, nil
	}
	db, err := strconv.Atoi(os.Getenv("REDIS_DB"))
	if err != nil {
		db = 0
	}

	client := redis.NewClient(&redis.Options{
		Addr:      redisAddr,
		Username:  os.Getenv("REDIS_USERNAME"),
		Password:  os.Getenv("REDIS_PASSWORD"),
		DB:        db,
		TLSConfig: common.RedisTLSConfig(),
	})

	_, err = client.Ping(context.Background()).Result()
	if err != nil {
		return nil, fmt.Errorf("连接Redis失败: %w", err)
	}

	return client, nil
}

// initDatabase initializes database connection
// Creates and configures database connection based on environment configuration
// Supports multiple database backends (PostgreSQL)
// Parameters:
//   - cfg: Application configuration
//
// Returns:
//   - Configured database connection
//   - Error if connection fails
func initDatabase(cfg *config.Config) (*gorm.DB, error) {
	var dialector gorm.Dialector
	var migrateDSN string
	var sqliteDBPath string
	switch os.Getenv("DB_DRIVER") {
	case "postgres":
		// DSN for GORM (key-value format)
		gormDSN := fmt.Sprintf(
			"host=%s port=%s user=%s password=%s dbname=%s sslmode=%s TimeZone=UTC",
			os.Getenv("DB_HOST"),
			os.Getenv("DB_PORT"),
			os.Getenv("DB_USER"),
			os.Getenv("DB_PASSWORD"),
			os.Getenv("DB_NAME"),
			"disable",
		)
		dialector = postgres.Open(gormDSN)

		// DSN for golang-migrate (URL format)
		// URL-encode password to handle special characters like !@#
		dbPassword := os.Getenv("DB_PASSWORD")
		encodedPassword := url.QueryEscape(dbPassword)

		// Check if postgres is in RETRIEVE_DRIVER to determine skip_embedding
		retrieveDriver := strings.Split(os.Getenv("RETRIEVE_DRIVER"), ",")
		skipEmbedding := "true"
		if slices.Contains(retrieveDriver, "postgres") {
			skipEmbedding = "false"
		}
		logger.Infof(context.Background(), "Skip embedding: %s", skipEmbedding)

		migrateDSN = fmt.Sprintf(
			"postgres://%s:%s@%s:%s/%s?sslmode=disable&options=-c%%20app.skip_embedding=%s",
			os.Getenv("DB_USER"),
			encodedPassword, // Use encoded password
			os.Getenv("DB_HOST"),
			os.Getenv("DB_PORT"),
			os.Getenv("DB_NAME"),
			skipEmbedding,
		)

		// Debug log (don't log password)
		logger.Infof(context.Background(), "DB Config: user=%s host=%s port=%s dbname=%s",
			os.Getenv("DB_USER"),
			os.Getenv("DB_HOST"),
			os.Getenv("DB_PORT"),
			os.Getenv("DB_NAME"),
		)
	case "sqlite":
		dbPath := os.Getenv("DB_PATH")
		if dbPath == "" {
			dbPath = "./data/weknora.db"
		}
		if dir := filepath.Dir(dbPath); dir != "." && dir != "" {
			if err := os.MkdirAll(dir, 0o755); err != nil {
				return nil, fmt.Errorf("failed to create SQLite data directory %s: %w", dir, err)
			}
		}
		sqlite_vec.Auto()
		dsn := dbPath + "?_journal_mode=WAL&_busy_timeout=5000&_foreign_keys=on"
		dialector = sqlite.Open(dsn)
		sqliteDBPath = dbPath
		migrateDSN = "sqlite3://" + dbPath
		logger.Infof(context.Background(), "DB Config: driver=sqlite path=%s", dbPath)
	default:
		return nil, fmt.Errorf("unsupported database driver: %s", os.Getenv("DB_DRIVER"))
	}
	db, err := gorm.Open(dialector, &gorm.Config{
		NowFunc: func() time.Time {
			return time.Now().UTC()
		},
	})
	if err != nil {
		return nil, err
	}

	// Sanity check: dialect-specific code in services (notably the
	// vector_stores delete guard) compares Dialector.Name() to "postgres" /
	// "sqlite" string literals. A future driver swap that produces a
	// different name (e.g., a wrapper dialect for managed PG) would silently
	// fall back to the SQLite path, dropping the row-level X-lock. Catching
	// the mismatch at startup is loud and inexpensive.
	if name := db.Dialector.Name(); name != "postgres" && name != "sqlite" {
		return nil, fmt.Errorf(
			"unsupported gorm dialector %q; expected postgres or sqlite "+
				"(see vectorStoreService.isPostgres for impact)", name)
	}

	if os.Getenv("DB_DRIVER") == "sqlite" {
		sqlDB, err := db.DB()
		if err != nil {
			return nil, fmt.Errorf("failed to get underlying sql.DB: %w", err)
		}
		if err := sqlDB.Ping(); err != nil {
			return nil, fmt.Errorf("failed to ping SQLite database: %w", err)
		}
	}

	// Run database migrations automatically (optional, can be disabled via env var)
	// To disable auto-migration, set AUTO_MIGRATE=false
	// To enable auto-recovery from dirty state, set AUTO_RECOVER_DIRTY=true
	if os.Getenv("AUTO_MIGRATE") != "false" {
		logger.Infof(context.Background(), "Running database migrations...")

		autoRecover := os.Getenv("AUTO_RECOVER_DIRTY") != "false"
		migrationOpts := database.MigrationOptions{
			AutoRecoverDirty: autoRecover,
			SQLiteDBPath:     sqliteDBPath,
		}

		// Run base migrations (all versioned migrations including embeddings)
		// The embeddings migration will be conditionally executed based on skip_embedding parameter in DSN
		if err := database.RunMigrationsWithOptions(migrateDSN, migrationOpts); err != nil {
			// Log warning but don't fail startup - migrations might be handled externally
			logger.Warnf(context.Background(), "Database migration failed: %v", err)
			logger.Warnf(
				context.Background(),
				"Continuing with application startup. Please run migrations manually if needed.",
			)
		}

		// Post-migration: resolve __pending_env__ storage provider markers for historical KBs.
		// The SQL migration marks KBs that have documents but no provider with "__pending_env__";
		// we replace that with the actual STORAGE_TYPE from the environment.
		resolveStorageProviderPending(db)
		migrateLegacyStorageBackends(db)

		// Post-migration: declarative built-in models from config/builtin_models.yaml (optional).
		if err := types.LoadBuiltinModelsConfig(context.Background(), db, config.ConfigDir()); err != nil {
			logger.Warnf(context.Background(), "Load builtin models config failed: %v", err)
		}
	} else {
		logger.Infof(context.Background(), "Auto-migration is disabled (AUTO_MIGRATE=false)")
	}

	// Get underlying SQL DB object
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	// Configure connection pool parameters
	if os.Getenv("DB_DRIVER") == "sqlite" {
		// SQLite only supports one concurrent writer even in WAL mode.
		// Limiting to a single open connection serialises all DB access and
		// prevents "database is locked" errors from concurrent goroutines.
		sqlDB.SetMaxOpenConns(1)
	} else {
		sqlDB.SetMaxIdleConns(10)
	}
	sqlDB.SetConnMaxLifetime(time.Duration(10) * time.Minute)

	return db, nil
}

// resolveStorageProviderPending replaces the "__pending_env__" sentinel in
// knowledge_bases.storage_provider_config with the actual STORAGE_TYPE from the environment.
// This runs once after SQL migrations to bind historical KBs to their real storage provider.
func resolveStorageProviderPending(db *gorm.DB) {
	storageType := strings.TrimSpace(os.Getenv("STORAGE_TYPE"))
	if storageType == "" {
		storageType = "local"
	}
	storageType = strings.ToLower(storageType)

	result := db.Exec(
		`UPDATE knowledge_bases SET storage_provider_config = ? WHERE storage_provider_config IS NOT NULL AND storage_provider_config->>'provider' = '__pending_env__'`,
		fmt.Sprintf(`{"provider":"%s"}`, storageType),
	)
	if result.Error != nil {
		logger.Warnf(context.Background(), "Failed to resolve __pending_env__ storage providers: %v", result.Error)
	} else if result.RowsAffected > 0 {
		logger.Infof(context.Background(), "Resolved %d knowledge bases with __pending_env__ storage provider → %s", result.RowsAffected, storageType)
	}

	// Sync PostgreSQL sequences with actual MAX values to prevent duplicate key
	// errors. The old code assigned seq_id via SELECT MAX()+1 in application
	// code, which could push values past the DB sequence counter.
	syncSequences(db)

	// Reset any pending tasks left over from previous aborted runs (Lite App mode)
	resetPendingTasks(db)
}

// migrateLegacyStorageBackends backfills the storage_backends table from each
// workspace's legacy StorageEngineConfig (or environment defaults) and binds
// existing knowledge bases to the resulting backend.
//
// The table, columns and indexes are created by the SQL migrations
// (migrations/versioned/000068 for Postgres, migrations/sqlite/000000_init for
// SQLite); this step only handles data that cannot be expressed portably in
// SQL: environment snapshots, JSON→config mapping, AES-encrypted credentials,
// UUID generation and the per-startup refresh of env-backed aliases.
// The migration is idempotent: one legacy_alias row per tenant/provider.
func migrateLegacyStorageBackends(db *gorm.DB) {
	var tenants []*types.Tenant
	if err := db.Find(&tenants).Error; err != nil {
		logger.Warnf(context.Background(), "Failed to load workspaces for storage backend migration: %v", err)
		return
	}
	if len(tenants) == 0 {
		return
	}

	// Load every alias in a single query. Probing each tenant/provider pair with
	// First() makes GORM log "record not found" for every miss, which floods the
	// startup log with workspaces × providers lines on fresh installs.
	var aliases []*types.StorageBackend
	if err := db.Where("legacy_alias = ?", true).Find(&aliases).Error; err != nil {
		logger.Warnf(context.Background(), "Failed to load legacy storage aliases: %v", err)
		return
	}
	existingAliases := make(map[uint64]map[string]*types.StorageBackend, len(aliases))
	for _, alias := range aliases {
		byProvider := existingAliases[alias.TenantID]
		if byProvider == nil {
			byProvider = make(map[string]*types.StorageBackend)
			existingAliases[alias.TenantID] = byProvider
		}
		byProvider[alias.Provider] = alias
	}

	for _, tenant := range tenants {
		legacy := tenant.StorageEngineConfig
		defaultProvider := ""
		if legacy != nil {
			defaultProvider = strings.ToLower(strings.TrimSpace(legacy.DefaultProvider))
		}
		if defaultProvider == "" {
			defaultProvider = strings.ToLower(strings.TrimSpace(os.Getenv("STORAGE_TYPE")))
		}
		if defaultProvider == "" {
			defaultProvider = "local"
		}

		backendIDs := make(map[string]string)
		for _, provider := range storageallowlist.Supported() {
			if existing := existingAliases[tenant.ID][provider]; existing != nil {
				// Environment-backed aliases are snapshots, not user-owned config.
				// Refresh them at every startup so credential rotation does not
				// leave the persisted resolver on stale values. If the workspace
				// later gains an explicit legacy config, promote the alias to user
				// source and stop automatic refreshes.
				if existing.Source == types.StorageBackendSourceEnv {
					desired := types.StorageBackendFromLegacy(tenant.ID, provider, legacy)
					if desired == nil && provider == defaultProvider {
						desired = types.StorageBackendFromEnvironment(tenant.ID)
					}
					if desired != nil && desired.Provider == provider {
						_ = db.Model(&types.StorageBackend{}).Where("id = ?", existing.ID).Updates(map[string]interface{}{
							"name": desired.Name, "config": desired.Config, "source": desired.Source, "status": desired.Status, "updated_at": time.Now(),
						}).Error
					}
				}
				backendIDs[provider] = existing.ID
				continue
			}
			backend := types.StorageBackendFromLegacy(tenant.ID, provider, legacy)
			if backend == nil && provider == defaultProvider {
				backend = types.StorageBackendFromEnvironment(tenant.ID)
			}
			if backend == nil {
				continue
			}
			if err := db.Create(backend).Error; err != nil {
				logger.Warnf(context.Background(), "Failed to migrate %s storage for workspace %d: %v", provider, tenant.ID, err)
				continue
			}
			backendIDs[provider] = backend.ID
		}
		if tenant.DefaultStorageBackendID == nil {
			if id := backendIDs[defaultProvider]; id != "" {
				if err := db.Model(&types.Tenant{}).Where("id = ?", tenant.ID).Update("default_storage_backend_id", id).Error; err != nil {
					logger.Warnf(context.Background(), "Failed to set default storage backend for workspace %d: %v", tenant.ID, err)
				}
			}
		}

		var kbs []*types.KnowledgeBase
		if err := db.Where("tenant_id = ? AND storage_backend_id IS NULL", tenant.ID).Find(&kbs).Error; err != nil {
			continue
		}
		for _, kb := range kbs {
			provider := kb.GetStorageProvider()
			if provider == "" {
				provider = defaultProvider
			}
			if id := backendIDs[provider]; id != "" {
				_ = db.Model(&types.KnowledgeBase{}).Where("id = ? AND storage_backend_id IS NULL", kb.ID).Update("storage_backend_id", id).Error
			}
		}
	}
}

// syncSequences ensures PostgreSQL sequences for auto-increment columns (seq_id)
// are at least as high as the current MAX value in each table. This is needed
// because older code assigned seq_id via application-level MAX()+1, which could
// advance values past the DB sequence counter and cause duplicate key errors.
func syncSequences(db *gorm.DB) {
	if db.Dialector.Name() != "postgres" {
		return
	}
	pairs := [][2]string{
		{"chunks", "chunks_seq_id_seq"},
		{"knowledge_tags", "knowledge_tags_seq_id_seq"},
	}
	for _, p := range pairs {
		table, seq := p[0], p[1]
		sql := fmt.Sprintf(
			`SELECT setval('%s', GREATEST(nextval('%s'), (SELECT COALESCE(MAX(seq_id), 0) FROM %s)))`,
			seq, seq, table,
		)
		if err := db.Exec(sql).Error; err != nil {
			logger.Warnf(context.Background(), "Failed to sync sequence %s: %v", seq, err)
		} else {
			logger.Infof(context.Background(), "Synced sequence %s with table %s", seq, table)
		}
	}
}

// initFileService initializes file storage service
// Creates the appropriate file storage service based on configuration
// Supports multiple storage backends (MinIO, COS, local filesystem)
// Parameters:
//   - cfg: Application configuration
//
// Returns:
//   - Configured file service implementation
//   - Error if initialization fails
func initFileService(cfg *config.Config, catalog interfaces.ResourceCatalog) (interfaces.FileService, error) {
	inner, err := initRawFileService(cfg)
	if err != nil {
		return nil, err
	}
	return file.NewResourceCatalogFileService(inner, catalog), nil
}

func initRawFileService(_ *config.Config) (interfaces.FileService, error) {
	storageType := strings.TrimSpace(os.Getenv("STORAGE_TYPE"))
	if storageType == "" {
		storageType = "local"
	}
	switch storageType {
	case "minio":
		if os.Getenv("MINIO_ENDPOINT") == "" ||
			os.Getenv("MINIO_ACCESS_KEY_ID") == "" ||
			os.Getenv("MINIO_SECRET_ACCESS_KEY") == "" ||
			os.Getenv("MINIO_BUCKET_NAME") == "" {
			return nil, fmt.Errorf("missing MinIO configuration")
		}
		return file.NewMinioFileService(
			os.Getenv("MINIO_ENDPOINT"),
			os.Getenv("MINIO_ACCESS_KEY_ID"),
			os.Getenv("MINIO_SECRET_ACCESS_KEY"),
			os.Getenv("MINIO_BUCKET_NAME"),
			strings.EqualFold(os.Getenv("MINIO_USE_SSL"), "true"),
		)
	case "cos":
		if os.Getenv("COS_BUCKET_NAME") == "" ||
			os.Getenv("COS_REGION") == "" ||
			os.Getenv("COS_SECRET_ID") == "" ||
			os.Getenv("COS_SECRET_KEY") == "" ||
			os.Getenv("COS_PATH_PREFIX") == "" {
			return nil, fmt.Errorf("missing COS configuration")
		}
		return file.NewCosFileServiceWithTempBucket(
			os.Getenv("COS_BUCKET_NAME"),
			os.Getenv("COS_REGION"),
			os.Getenv("COS_SECRET_ID"),
			os.Getenv("COS_SECRET_KEY"),
			os.Getenv("COS_PATH_PREFIX"),
			os.Getenv("COS_TEMP_BUCKET_NAME"),
			os.Getenv("COS_TEMP_REGION"),
		)
	case "tos":
		if os.Getenv("TOS_ENDPOINT") == "" ||
			os.Getenv("TOS_REGION") == "" ||
			os.Getenv("TOS_ACCESS_KEY") == "" ||
			os.Getenv("TOS_SECRET_KEY") == "" ||
			os.Getenv("TOS_BUCKET_NAME") == "" {
			return nil, fmt.Errorf("missing TOS configuration")
		}
		return file.NewTosFileServiceWithTempBucket(
			os.Getenv("TOS_ENDPOINT"),
			os.Getenv("TOS_REGION"),
			os.Getenv("TOS_ACCESS_KEY"),
			os.Getenv("TOS_SECRET_KEY"),
			os.Getenv("TOS_BUCKET_NAME"),
			os.Getenv("TOS_PATH_PREFIX"),
			os.Getenv("TOS_TEMP_BUCKET_NAME"), // 可选：临时桶名称（桶需配置生命周期规则自动过期）
			os.Getenv("TOS_TEMP_REGION"),      // 可选：临时桶 region，默认与主桶相同
		)
	case "s3":
		accessKey, secretKey := os.Getenv("S3_ACCESS_KEY"), os.Getenv("S3_SECRET_KEY")
		if os.Getenv("S3_REGION") == "" ||
			os.Getenv("S3_BUCKET_NAME") == "" ||
			(accessKey == "") != (secretKey == "") {
			return nil, fmt.Errorf("missing S3 configuration")
		}
		pathPrefix := os.Getenv("S3_PATH_PREFIX")
		if pathPrefix == "" {
			pathPrefix = "weknora/"
		}
		return file.NewS3FileService(
			os.Getenv("S3_ENDPOINT"),
			accessKey,
			secretKey,
			os.Getenv("S3_BUCKET_NAME"),
			os.Getenv("S3_REGION"),
			pathPrefix,
		)
	case "obs":
		if os.Getenv("OBS_ENDPOINT") == "" ||
			os.Getenv("OBS_ACCESS_KEY") == "" ||
			os.Getenv("OBS_SECRET_KEY") == "" ||
			os.Getenv("OBS_BUCKET_NAME") == "" {
			return nil, fmt.Errorf("missing OBS configuration")
		}
		obsRegion := os.Getenv("OBS_REGION")
		obsPathPrefix := os.Getenv("OBS_PATH_PREFIX")
		if obsPathPrefix == "" {
			obsPathPrefix = "weknora/"
		}
		return file.NewObsFileService(
			os.Getenv("OBS_ENDPOINT"),
			obsRegion,
			os.Getenv("OBS_ACCESS_KEY"),
			os.Getenv("OBS_SECRET_KEY"),
			os.Getenv("OBS_BUCKET_NAME"),
			obsPathPrefix,
		)
	case "oss":
		if os.Getenv("OSS_ENDPOINT") == "" ||
			os.Getenv("OSS_REGION") == "" ||
			os.Getenv("OSS_ACCESS_KEY") == "" ||
			os.Getenv("OSS_SECRET_KEY") == "" ||
			os.Getenv("OSS_BUCKET_NAME") == "" {
			return nil, fmt.Errorf("missing OSS configuration")
		}
		pathPrefix := os.Getenv("OSS_PATH_PREFIX")
		if pathPrefix == "" {
			pathPrefix = "weknora/"
		}
		return file.NewOssFileServiceWithTempBucket(
			os.Getenv("OSS_ENDPOINT"),
			os.Getenv("OSS_REGION"),
			os.Getenv("OSS_ACCESS_KEY"),
			os.Getenv("OSS_SECRET_KEY"),
			os.Getenv("OSS_BUCKET_NAME"),
			pathPrefix,
			os.Getenv("OSS_TEMP_BUCKET_NAME"),
			os.Getenv("OSS_TEMP_REGION"),
		)
	case "local":
		baseDir := os.Getenv("LOCAL_STORAGE_BASE_DIR")
		if baseDir == "" {
			baseDir = "/data/files"
		}
		externalURL := strings.TrimSpace(os.Getenv("APP_EXTERNAL_URL"))
		return file.NewLocalFileService(baseDir, externalURL), nil
	case "dummy":
		return file.NewDummyFileService(), nil
	default:
		return nil, fmt.Errorf("unsupported storage type: %s", storageType)
	}
}

// initRetrieveEngineRegistry initializes the retrieval engine registry
// Sets up and configures various search engine backends based on configuration
// Supports multiple retrieval engines (PostgreSQL, ElasticsearchV7, ElasticsearchV8)
// Parameters:
//   - db: Database connection
//   - cfg: Application configuration
//
// Returns:
//   - Configured retrieval engine registry
//   - Error if initialization fails
func initRetrieveEngineRegistry(
	db *gorm.DB, cfg *config.Config, auditSvc interfaces.AuditLogService,
	storeRepo interfaces.VectorStoreRepository, engineFactory interfaces.EngineFactory,
) (interfaces.RetrieveEngineRegistry, error) {
	// storeRepo and engineFactory let the registry rebuild a store engine that
	// is absent from this process, which happens when startup skipped it after
	// a construction failure or when another instance registered it.
	registry := retriever.NewRetrieveEngineRegistry(storeRepo, engineFactory)
	retrieveDriver := strings.Split(os.Getenv("RETRIEVE_DRIVER"), ",")
	log := logger.GetLogger(context.Background())
	// Audit sink for OpenSearch driver events (index created / reindex). Driver
	// events fire under a tenant-scoped ctx at indexing time; the env-path
	// registration ctx below has no tenant, so those emits self-skip.
	auditSink := newAuditSinkAdapter(auditSvc)

	if slices.Contains(retrieveDriver, "postgres") {
		postgresRepo := postgresRepo.NewPostgresRetrieveEngineRepository(db)
		if err := registry.Register(
			retriever.NewKVHybridRetrieveEngine(postgresRepo, types.PostgresRetrieverEngineType),
		); err != nil {
			log.Errorf("Register postgres retrieve engine failed: %v", err)
		} else {
			log.Infof("Register postgres retrieve engine success")
		}
	}
	if slices.Contains(retrieveDriver, "sqlite") {
		sqliteRepo := sqliteRetrieverRepo.NewSQLiteRetrieveEngineRepository(db)
		if err := registry.Register(
			retriever.NewKVHybridRetrieveEngine(sqliteRepo, types.SQLiteRetrieverEngineType),
		); err != nil {
			log.Errorf("Register sqlite retrieve engine failed: %v", err)
		} else {
			log.Infof("Register sqlite retrieve engine success")
		}
	}
	if slices.Contains(retrieveDriver, "elasticsearch_v8") {
		client, err := elasticsearch.NewTypedClient(elasticsearch.Config{
			Addresses: []string{os.Getenv("ELASTICSEARCH_ADDR")},
			Username:  os.Getenv("ELASTICSEARCH_USERNAME"),
			Password:  os.Getenv("ELASTICSEARCH_PASSWORD"),
		})
		if err != nil {
			log.Errorf("Create elasticsearch_v8 client failed: %v", err)
		} else {
			elasticsearchRepo := elasticsearchRepoV8.NewElasticsearchEngineRepository(client, cfg, nil)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					elasticsearchRepo, types.ElasticsearchRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register elasticsearch_v8 retrieve engine failed: %v", err)
			} else {
				log.Infof("Register elasticsearch_v8 retrieve engine success")
			}
		}
	}

	if slices.Contains(retrieveDriver, "elasticsearch_v7") {
		client, err := esv7.NewClient(esv7.Config{
			Addresses: []string{os.Getenv("ELASTICSEARCH_ADDR")},
			Username:  os.Getenv("ELASTICSEARCH_USERNAME"),
			Password:  os.Getenv("ELASTICSEARCH_PASSWORD"),
		})
		if err != nil {
			log.Errorf("Create elasticsearch_v7 client failed: %v", err)
		} else {
			elasticsearchRepo := elasticsearchRepoV7.NewElasticsearchEngineRepository(client, cfg, nil)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					elasticsearchRepo, types.ElasticsearchRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register elasticsearch_v7 retrieve engine failed: %v", err)
			} else {
				log.Infof("Register elasticsearch_v7 retrieve engine success")
			}
		}
	}

	if slices.Contains(retrieveDriver, "opensearch") {
		cc := &types.ConnectionConfig{
			Addr:               os.Getenv("OPENSEARCH_ADDR"),
			Username:           os.Getenv("OPENSEARCH_USERNAME"),
			Password:           os.Getenv("OPENSEARCH_PASSWORD"),
			InsecureSkipVerify: strings.EqualFold(os.Getenv("OPENSEARCH_INSECURE_SKIP_VERIFY"), "true"),
		}
		client, err := openSearchRepo.NewOpenSearchClient(cc)
		if err != nil {
			log.Errorf("Create opensearch client failed: %v", err)
		} else if repo, err := openSearchRepo.NewRepository(
			context.Background(), client, "", nil, openSearchRepo.WithAuditSink(auditSink),
		); err != nil {
			log.Errorf("Create opensearch repository failed: %v", err)
		} else if err := registry.Register(
			retriever.NewKVHybridRetrieveEngine(repo, types.OpenSearchRetrieverEngineType),
		); err != nil {
			log.Errorf("Register opensearch retrieve engine failed: %v", err)
		} else {
			log.Infof("Register opensearch retrieve engine success")
		}
	}

	if slices.Contains(retrieveDriver, "qdrant") {
		qdrantHost := os.Getenv("QDRANT_HOST")
		if qdrantHost == "" {
			qdrantHost = "localhost"
		}

		qdrantPort := 6334 // Default port
		if portStr := os.Getenv("QDRANT_PORT"); portStr != "" {
			if port, err := strconv.Atoi(portStr); err == nil {
				qdrantPort = port
			}
		}

		// API key for authentication (optional)
		qdrantAPIKey := os.Getenv("QDRANT_API_KEY")

		// TLS configuration (optional, defaults to false)
		// Enable TLS unless explicitly set to "false" or "0" (case insensitive)
		qdrantUseTLS := false
		if useTLSStr := os.Getenv("QDRANT_USE_TLS"); useTLSStr != "" {
			useTLSLower := strings.ToLower(strings.TrimSpace(useTLSStr))
			qdrantUseTLS = useTLSLower != "false" && useTLSLower != "0"
		}

		log.Infof("Connecting to Qdrant at %s:%d (TLS: %v)", qdrantHost, qdrantPort, qdrantUseTLS)

		client, err := qdrant.NewClient(&qdrant.Config{
			Host:   qdrantHost,
			Port:   qdrantPort,
			APIKey: qdrantAPIKey,
			UseTLS: qdrantUseTLS,
		})
		if err != nil {
			log.Errorf("Create qdrant client failed: %v", err)
		} else {
			qdrantRepository := qdrantRepo.NewQdrantRetrieveEngineRepository(client, nil)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					qdrantRepository, types.QdrantRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register qdrant retrieve engine failed: %v", err)
			} else {
				log.Infof("Register qdrant retrieve engine success")
			}
		}
	}
	if slices.Contains(retrieveDriver, "weaviate") {
		weaviateHost := os.Getenv("WEAVIATE_HOST")
		if weaviateHost == "" {
			// Docker compose default (service name inside network)
			weaviateHost = "weaviate:8080"
		}
		weaviateGrpcAddress := os.Getenv("WEAVIATE_GRPC_ADDRESS")
		if weaviateGrpcAddress == "" {
			weaviateGrpcAddress = "weaviate:50051"
		}
		weaviateScheme := os.Getenv("WEAVIATE_SCHEME")
		if weaviateScheme == "" {
			weaviateScheme = "http"
		}
		var authConfig auth.Config
		if strings.EqualFold(strings.TrimSpace(os.Getenv("WEAVIATE_AUTH_ENABLED")), "true") {
			if apiKey := strings.TrimSpace(os.Getenv("WEAVIATE_API_KEY")); apiKey != "" {
				authConfig = auth.ApiKey{Value: apiKey}
			}
		}
		weaviateClient, err := weaviate.NewClient(weaviate.Config{
			Host: weaviateHost,
			GrpcConfig: &wgrpc.Config{
				Host: weaviateGrpcAddress,
			},
			Scheme:     weaviateScheme,
			AuthConfig: authConfig,
		})
		if err != nil {
			log.Errorf("Create weaviate client failed: %v", err)
		} else {
			weaviateRepository := weaviateRepo.NewWeaviateRetrieveEngineRepository(weaviateClient, nil)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					weaviateRepository, types.WeaviateRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register weaviate retrieve engine failed: %v", err)
			} else {
				log.Infof("Register weaviate retrieve engine success")
			}
		}
	}
	if slices.Contains(retrieveDriver, "milvus") {
		milvusCfg := milvusclient.ClientConfig{
			DialOptions: []grpc.DialOption{grpc.WithTimeout(5 * time.Second)},
		}
		milvusAddress := os.Getenv("MILVUS_ADDRESS")
		if milvusAddress == "" {
			milvusAddress = "localhost:19530"
		}
		milvusCfg.Address = milvusAddress
		milvusUsername := os.Getenv("MILVUS_USERNAME")
		if milvusUsername != "" {
			milvusCfg.Username = milvusUsername
		}
		milvusPassword := os.Getenv("MILVUS_PASSWORD")
		if milvusPassword != "" {
			milvusCfg.Password = milvusPassword
		}
		milvusDBName := os.Getenv("MILVUS_DB_NAME")
		if milvusDBName != "" {
			milvusCfg.DBName = milvusDBName
		}
		milvusCli, err := milvusclient.New(context.Background(), &milvusCfg)
		if err != nil {
			log.Errorf("Create milvus client failed: %v", err)
		} else {
			milvusRepository := milvusRepo.NewMilvusRetrieveEngineRepository(milvusCli, nil)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					milvusRepository, types.MilvusRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register milvus retrieve engine failed: %v", err)
			} else {
				log.Infof("Register milvus retrieve engine success")
			}
		}
	}
	if slices.Contains(retrieveDriver, "doris") {
		dorisAddr := os.Getenv("DORIS_ADDR")
		if dorisAddr == "" {
			// docker-compose 默认服务名 + Doris FE MySQL 端口
			dorisAddr = "doris-fe:9030"
		}
		dorisDatabase := os.Getenv("DORIS_DATABASE")
		if dorisDatabase == "" {
			dorisDatabase = "weknora"
		}
		dorisUsername := os.Getenv("DORIS_USERNAME")
		if dorisUsername == "" {
			dorisUsername = "root"
		}
		dorisPassword := os.Getenv("DORIS_PASSWORD")
		dorisHTTPPort := 8030
		if portStr := os.Getenv("DORIS_HTTP_PORT"); portStr != "" {
			if port, err := strconv.Atoi(portStr); err == nil {
				dorisHTTPPort = port
			}
		}

		dsn := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=true&loc=Local&interpolateParams=true",
			dorisUsername, dorisPassword, dorisAddr, dorisDatabase)
		dorisDB, err := sql.Open("mysql", dsn)
		if err != nil {
			log.Errorf("Create doris client failed: %v", err)
		} else {
			dorisDB.SetMaxOpenConns(20)
			dorisDB.SetMaxIdleConns(5)
			dorisDB.SetConnMaxLifetime(time.Hour)

			httpBase := "http://" + hostFromAddr(dorisAddr) + ":" + strconv.Itoa(dorisHTTPPort)
			dorisRepository := dorisRepo.NewDorisRetrieveEngineRepository(
				dorisDB, httpBase, dorisUsername, dorisPassword, dorisDatabase, nil,
			)
			if err := registry.Register(
				retriever.NewKVHybridRetrieveEngine(
					dorisRepository, types.DorisRetrieverEngineType,
				),
			); err != nil {
				log.Errorf("Register doris retrieve engine failed: %v", err)
			} else {
				log.Infof("Register doris retrieve engine success: %s db=%s", dorisAddr, dorisDatabase)
			}
		}
	}
	if slices.Contains(retrieveDriver, "tencent_vectordb") {
		addr := os.Getenv("TENCENT_VECTORDB_ADDR")
		username := os.Getenv("TENCENT_VECTORDB_USERNAME")
		apiKey := os.Getenv("TENCENT_VECTORDB_API_KEY")
		if addr == "" || username == "" || apiKey == "" {
			log.Errorf("Missing Tencent VectorDB configuration")
		} else {
			client, err := tcvectordb.NewRpcClient(addr, username, apiKey, &tcvectordb.ClientOption{
				ReadConsistency: tcvectordb.EventualConsistency,
				Timeout:         10 * time.Second,
			})
			if err != nil {
				log.Errorf("Create tencent_vectordb client failed: %v", err)
			} else {
				tencentRepository := tencentVectorDBRepo.NewTencentVectorDBRetrieveEngineRepository(
					client,
					os.Getenv("TENCENT_VECTORDB_DATABASE"),
					nil,
				)
				if err := registry.Register(
					retriever.NewKVHybridRetrieveEngine(
						tencentRepository, types.TencentVectorDBRetrieverEngineType,
					),
				); err != nil {
					log.Errorf("Register tencent_vectordb retrieve engine failed: %v", err)
				} else {
					log.Infof("Register tencent_vectordb retrieve engine success")
				}
			}
		}
	}
	// ─── DB store registration (byStoreID) ───
	if storeReg, ok := registry.(*retriever.RetrieveEngineRegistry); ok {
		loadDBStoresIntoRegistry(storeReg, db, cfg, auditSink)
	}

	return registry, nil
}

// loadDBStoresIntoRegistry loads VectorStore records from DB and registers them
// in the registry's byStoreID map. Failures are logged and skipped (non-fatal).
func loadDBStoresIntoRegistry(
	storeRegistry interfaces.StoreRegistry, db *gorm.DB, cfg *config.Config, auditSink openSearchRepo.AuditSink,
) {
	ctx := context.Background()
	log := logger.GetLogger(ctx)

	var stores []types.VectorStore
	// GORM soft delete automatically adds "deleted_at IS NULL" condition
	if err := db.Find(&stores).Error; err != nil {
		log.Warnf("Failed to load vector stores from DB: %v", err)
		return
	}

	if len(stores) == 0 {
		return
	}

	log.Infof("Loading %d vector store(s) from database", len(stores))
	for _, store := range stores {
		svc, err := createEngineServiceFromStore(ctx, store, db, cfg, auditSink)
		if err != nil {
			log.Errorf("Failed to create engine for store %s (%s): %v", store.ID, store.Name, err)
			continue
		}
		storeRegistry.RegisterWithStoreID(store.ID, svc)
		log.Infof("Registered DB vector store: id=%s, name=%s, engine=%s", store.ID, store.Name, store.EngineType)
	}
}

// initAntsPool initializes the goroutine pool
// Creates a managed goroutine pool for concurrent task execution
// Parameters:
//   - cfg: Application configuration
//
// Returns:
//   - Configured goroutine pool
//   - Error if initialization fails
func initAntsPool(cfg *config.Config) (*ants.Pool, error) {
	// Default to 5 if not specified in config
	poolSize := os.Getenv("CONCURRENCY_POOL_SIZE")
	if poolSize == "" {
		poolSize = "5"
	}
	poolSizeInt, err := strconv.Atoi(poolSize)
	if err != nil {
		return nil, err
	}
	// Set up the pool with pre-allocation for better performance
	return ants.NewPool(poolSizeInt, ants.WithPreAlloc(true))
}

// registerPoolCleanup registers the goroutine pool for cleanup
// Ensures proper cleanup of the goroutine pool when application shuts down
// Parameters:
//   - pool: Goroutine pool
//   - cleaner: Resource cleaner
func registerPoolCleanup(pool *ants.Pool, cleaner interfaces.ResourceCleaner) {
	cleaner.RegisterWithName("AntsPool", func() error {
		pool.Release()
		return nil
	})
}

// registerLangfuseCleanup ensures buffered Langfuse events are flushed on
// shutdown. A 5-second timeout matches other external-service cleanups and
// balances data durability against a slow remote endpoint holding up exit.
func registerLangfuseCleanup(mgr *langfuse.Manager, cleaner interfaces.ResourceCleaner) {
	if mgr == nil {
		return
	}
	cleaner.RegisterWithName("Langfuse", func() error {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		return mgr.Shutdown(ctx)
	})
}

// initDocReaderClient initializes the DocumentReader client (lightweight API).
func initDocReaderClient(cfg *config.Config) (interfaces.DocumentReader, error) {
	addr := strings.TrimSpace(os.Getenv("DOCREADER_ADDR"))
	transport := strings.TrimSpace(os.Getenv("DOCREADER_TRANSPORT"))
	if transport == "" {
		transport = "grpc"
	}
	if addr == "" {
		logger.Infof(context.Background(), "[DocConverter] No DOCREADER_ADDR configured, starting disconnected")
	}
	transport = strings.ToLower(transport)
	switch transport {
	case "http", "https":
		if addr != "" && !strings.HasPrefix(addr, "http://") && !strings.HasPrefix(addr, "https://") {
			addr = "http://" + addr
		}
		return docparser.NewHTTPDocumentReader(addr)
	default:
		return docparser.NewGRPCDocumentReader(addr)
	}
}

// initOllamaService initializes the Ollama service client
// Creates a client for interacting with Ollama API for model inference
// Parameters:
//   - None
//
// Returns:
//   - Configured Ollama service client
//   - Error if initialization fails
func initOllamaService() (*ollama.OllamaService, error) {
	// Get Ollama service from existing factory function
	return ollama.GetOllamaService()
}

func initNeo4jClient() (neo4j.Driver, error) {
	ctx := context.Background()
	if strings.ToLower(os.Getenv("NEO4J_ENABLE")) != "true" {
		logger.Debugf(ctx, "NOT SUPPORT RETRIEVE GRAPH")
		return nil, nil
	}
	uri := os.Getenv("NEO4J_URI")
	username := os.Getenv("NEO4J_USERNAME")
	password := os.Getenv("NEO4J_PASSWORD")

	// Retry configuration
	maxRetries := 30                 // Max retry attempts
	retryInterval := 2 * time.Second // Wait between retries

	var driver neo4j.Driver
	var err error

	for attempt := 1; attempt <= maxRetries; attempt++ {
		driver, err = neo4j.NewDriver(uri, neo4j.BasicAuth(username, password, ""))
		if err != nil {
			logger.Warnf(ctx, "Failed to create Neo4j driver (attempt %d/%d): %v", attempt, maxRetries, err)
			time.Sleep(retryInterval)
			continue
		}

		err = driver.VerifyAuthentication(ctx, nil)
		if err == nil {
			if attempt > 1 {
				logger.Infof(ctx, "Successfully connected to Neo4j after %d attempts", attempt)
			}
			return driver, nil
		}

		logger.Warnf(ctx, "Failed to verify Neo4j authentication (attempt %d/%d): %v", attempt, maxRetries, err)
		driver.Close(ctx)
		time.Sleep(retryInterval)
	}

	return nil, fmt.Errorf("failed to connect to Neo4j after %d attempts: %w", maxRetries, err)
}

func NewDuckDB() (*sql.DB, error) {
	sqlDB, err := sql.Open("duckdb", ":memory:")
	if err != nil {
		return nil, fmt.Errorf("failed to open duckdb: %w", err)
	}

	// Try to install and load required extensions unless explicitly disabled.
	//   - spatial: used for st_read_meta() to enumerate layer (sheet) names from .xlsx/.xls
	//   - excel:   used for read_xlsx() which gives proper type inference per sheet
	//
	// INSTALL hits extensions.duckdb.org (public internet). In locked-down
	// runtimes with no egress, set DUCKDB_SKIP_EXTENSION_LOAD=1 to avoid a
	// startup hang; xlsx/xls ingest may fail later without these extensions.
	if strings.EqualFold(os.Getenv("DUCKDB_SKIP_EXTENSION_LOAD"), "true") ||
		os.Getenv("DUCKDB_SKIP_EXTENSION_LOAD") == "1" {
		logger.Infof(context.Background(),
			"[DuckDB] Skipping spatial/excel extension install/load "+
				"(DUCKDB_SKIP_EXTENSION_LOAD is set; xlsx ingest may fail without them)")
	} else {
		bgCtx := context.Background()
		for _, ext := range []string{"spatial", "excel"} {
			if _, err := sqlDB.ExecContext(bgCtx, fmt.Sprintf("INSTALL %s;", ext)); err != nil {
				logger.Warnf(bgCtx, "[DuckDB] Failed to install %s extension: %v", ext, err)
			}
			if _, err := sqlDB.ExecContext(bgCtx, fmt.Sprintf("LOAD %s;", ext)); err != nil {
				logger.Warnf(bgCtx, "[DuckDB] Failed to load %s extension: %v", ext, err)
			}
		}
	}

	return sqlDB, nil
}

// registerWebSearchProviders registers all web search provider types to the registry.
// Each provider type is registered with its factory function that accepts parameters.
// Provider instances are created on-demand when tenants configure them.
func registerWebSearchProviders(registry *infra_web_search.Registry) {
	registry.Register("duckduckgo", infra_web_search.NewDuckDuckGoProvider)
	registry.Register("google", infra_web_search.NewGoogleProvider)
	registry.Register("bing", infra_web_search.NewBingProvider)
	registry.Register("tavily", infra_web_search.NewTavilyProvider)
	registry.Register("ollama", infra_web_search.NewOllamaProvider)
	registry.Register("baidu", infra_web_search.NewBaiduProvider)
	registry.Register("searxng", infra_web_search.NewSearxngProvider)
	registry.Register("keenable", infra_web_search.NewKeenableProvider)
	registry.Register("zhipu", infra_web_search.NewZhipuProvider)
	registry.Register("exa", infra_web_search.NewExaProvider)
	registry.Register("metaso", infra_web_search.NewMetasoProvider)
	registry.Register("bocha", infra_web_search.NewBochaProvider)
	registry.Register("brave", infra_web_search.NewBraveProvider)
	registry.Register("serply", infra_web_search.NewSerplyProvider)
}

// registerIMService registers adapter factories, loads enabled channels, and
// wires the process-lifetime shutdown hook. Each platform's factory lives in
// its own subpackage to keep this file focused on wiring.
func registerIMService(imService *imPkg.Service, cleaner interfaces.ResourceCleaner) {
	imService.RegisterAdapterFactory("wecom", wecom.NewFactory())
	imService.RegisterAdapterFactory("feishu", feishu.NewFactory(feishu.RegionFeishu))
	// Lark is Feishu's international cloud: same adapter, different host/tenant.
	imService.RegisterAdapterFactory("lark", feishu.NewFactory(feishu.RegionLark))
	imService.RegisterAdapterFactory("slack", slack.NewFactory())
	imService.RegisterAdapterFactory("telegram", telegram.NewFactory())
	imService.RegisterAdapterFactory("dingtalk", dingtalk.NewFactory())
	imService.RegisterAdapterFactory("mattermost", mattermost.NewFactory())
	imService.RegisterAdapterFactory("wechat", wechat.NewFactory())
	imService.RegisterAdapterFactory("qqbot", qqbot.NewFactory())
	imService.RegisterAdapterFactory("yunzhijia", yunzhijia.NewFactory())

	// Load and start all enabled channels from database
	if err := imService.LoadAndStartChannels(); err != nil {
		logger.Warnf(context.Background(), "[IM] Failed to load channels from database: %v", err)
	}

	cleaner.RegisterWithName("IMService", func() error {
		imService.Stop()
		return nil
	})
}

// initConnectorRegistry creates and populates the connector registry with all available connectors.
// Aggregates registration errors via errors.Join so a misconfigured or duplicated connector fails
// container initialization loudly instead of silently disabling the feature at runtime.
func initConnectorRegistry() (*datasource.ConnectorRegistry, error) {
	registry := datasource.NewConnectorRegistry()

	var errs error
	if err := registry.Register(wiki.NewConnector(core.RegionFeishu)); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register feishu connector: %w", err))
	}
	// Lark is Feishu's international cloud: same connector, different host/tenant.
	if err := registry.Register(wiki.NewConnector(core.RegionLark)); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register lark connector: %w", err))
	}
	// Feishu/Lark Drive (云盘) mode: different connector type so the registry
	// dispatches to the Drive connector. Shares core.Client/Region/export logic
	// with the wiki connector. See 飞书云盘数据源设计.md / ADR-0001.
	if err := registry.Register(drive.NewDriveConnector(core.RegionFeishuDrive)); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register feishu_drive connector: %w", err))
	}
	if err := registry.Register(drive.NewDriveConnector(core.RegionLarkDrive)); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register lark_drive connector: %w", err))
	}
	if err := registry.Register(notionConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register notion connector: %w", err))
	}
	if err := registry.Register(yuqueConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register yuque connector: %w", err))
	}
	if err := registry.Register(imaConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register ima connector: %w", err))
	}
	if err := registry.Register(rssConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register rss connector: %w", err))
	}
	if err := registry.Register(gitlabConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register gitlab connector: %w", err))
	}
	if err := registry.Register(confluenceConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register confluence connector: %w", err))
	}
	if err := registry.Register(dingtalkConnector.NewConnector()); err != nil {
		errs = errors.Join(errs, fmt.Errorf("register dingtalk connector: %w", err))
	}

	// Future connectors will be registered here:
	// if err := registry.Register(githubConnector.NewConnector()); err != nil { ... }

	if errs != nil {
		return nil, errs
	}
	return registry, nil
}

// injectDataSourceTaskInspector wires the queue inspector into the data source
// service so delete/pause can hard-cancel queued (and running) datasource:sync
// tasks (SP2-a Task 5). Setter injection mirrors SetSyncExecution. In asynq
// mode this is the real inspector; in Lite mode it is the no-op one, and the
// service internally falls back to the sync-log sweep.
func injectDataSourceTaskInspector(svc interfaces.DataSourceService, inspector interfaces.TaskInspector) {
	if impl, ok := svc.(*service.DataSourceService); ok && impl != nil {
		impl.SetTaskInspector(inspector)
	}
}

// startDataSourceScheduler starts the data source cron scheduler and registers cleanup.
func startDataSourceScheduler(scheduler *datasource.Scheduler, cleaner interfaces.ResourceCleaner) {
	if err := scheduler.Start(context.Background()); err != nil {
		logger.Warnf(context.Background(), "[Container] data source scheduler start failed: %v", err)
	}

	cleaner.RegisterWithName("DataSourceScheduler", func() error {
		scheduler.Stop()
		return nil
	})
}

// startHousekeepingService starts the knowledge housekeeping cron and registers
// cleanup. This is the safety net that recovers any knowledge stuck in
// "processing" past a configurable threshold (see HousekeepingService for
// rationale). Best-effort: a startup error is logged but does NOT abort the
// container — the rest of the system stays usable.
func startHousekeepingService(svc *service.HousekeepingService, cleaner interfaces.ResourceCleaner) {
	if svc == nil {
		return
	}
	if err := svc.Start(context.Background()); err != nil {
		logger.Warnf(context.Background(), "[Container] housekeeping start failed: %v", err)
	}
	cleaner.RegisterWithName("KnowledgeHousekeeping", func() error {
		svc.Stop()
		return nil
	})
}

// startTenantSkillReaper starts the stuck-install / orphan-snapshot cron and
// registers cleanup. Best-effort: a startup error is logged but does NOT abort
// the container — the rest of the system stays usable.
func startTenantSkillReaper(svc *service.TenantSkillService, cleaner interfaces.ResourceCleaner) {
	if svc == nil {
		return
	}
	if err := svc.Start(context.Background()); err != nil {
		logger.Warnf(context.Background(), "[Container] tenant skill reaper start failed: %v", err)
	}
	cleaner.RegisterWithName("TenantSkillReaper", func() error {
		svc.Stop()
		return nil
	})
}

// startTemporaryDocumentCleanup removes expired session attachments and their
// extracted images. The durable expiry timestamp is the source of truth; the
// ticker only controls how quickly storage is reclaimed.
func startTemporaryDocumentCleanup(svc interfaces.TemporaryDocumentService, cleaner interfaces.ResourceCleaner) {
	stop := make(chan struct{})
	go func() {
		ticker := time.NewTicker(10 * time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				if err := svc.CleanupExpired(context.Background()); err != nil {
					logger.Warnf(context.Background(), "[TemporaryDocument] cleanup failed: %v", err)
				}
			case <-stop:
				return
			}
		}
	}()
	cleaner.RegisterWithName("TemporaryDocumentCleanup", func() error {
		close(stop)
		return nil
	})
}

// startAuditLogRetention spins up the daily audit_logs purge sweep
// and registers shutdown cleanup. Mirrors the data-source-scheduler
// pattern: container init kicks the goroutine, ResourceCleaner stops
// it during graceful shutdown so a SIGTERM during a sweep doesn't
// orphan the goroutine.
//
// retention_days <= 0 is the configured way to disable retention;
// the runner short-circuits Start() on that path so we don't need
// to gate the wiring here.
func startAuditLogRetention(
	runner *service.AuditLogRetentionRunner, cleaner interfaces.ResourceCleaner,
) {
	runner.Start(context.Background())
	cleaner.RegisterWithName("AuditLogRetentionRunner", func() error {
		runner.Stop()
		return nil
	})
}

func registerAgentRunResourceProtection(repo *service.GormAgentRunResourceRepository) {
	if repo == nil {
		sandbox.ConfigureDockerResourceProtection(nil)
		return
	}
	sandbox.ConfigureDockerResourceProtection(repo)
}

// startCommercialFulfillment registers the background recovery loop that
// drains fulfillment outbox events into external benefits. Payment callbacks
// only enqueue events; this loop runs after boot so callbacks never block on
// the gateway. Stop is registered with the resource cleaner so a graceful
// shutdown does not orphan the loop.
func startCommercialFulfillment(svc *commercialsvc.FulfillmentService, cleaner interfaces.ResourceCleaner) {
	svc.StartBackground(context.Background())
	cleaner.RegisterWithName("CommercialFulfillment", func() error {
		svc.Stop()
		return nil
	})
}

// craftFeatureGateFromEnv reads the craft feature gate following the
// WEKNORA_* env-switch convention (like the commercial rollout switches):
// craft is disabled unless WEKNORA_CRAFT_ENABLED is true, and even when
// enabled only the kinds listed in WEKNORA_CRAFT_KINDS are open. A valid
// kind is not an open kind.
func craftFeatureGateFromEnv() service.CraftFeatureGate {
	gate := service.CraftFeatureGate{Enabled: false}
	switch strings.ToLower(strings.TrimSpace(os.Getenv("WEKNORA_CRAFT_ENABLED"))) {
	case "true", "1", "yes":
		gate.Enabled = true
	}
	kinds := make([]string, 0, 4)
	for _, raw := range strings.Split(os.Getenv("WEKNORA_CRAFT_KINDS"), ",") {
		kind := strings.TrimSpace(raw)
		if craft.KnownKind(kind) {
			kinds = append(kinds, kind)
		}
	}
	if len(kinds) == 0 {
		kinds = []string{craft.KindWeb}
	}
	gate.Kinds = kinds
	return gate
}

// newCraftSessionService assembles W03's craft session service from the
// already-registered craft stores and the existing session, upload, file and
// model services. New runs are admitted through the live agent run service.
func newCraftSessionService(
	db *gorm.DB,
	sessions interfaces.SessionService,
	store craft.Store,
	versions craft.VersionStore,
	documents interfaces.TemporaryDocumentService,
	files interfaces.FileService,
	models interfaces.ModelService,
	access *service.CraftAccessService,
	runtime *AgentRuntime,
) (*service.CraftSessionService, error) {
	runs := runtime.Runs
	if runs == nil {
		runs = service.RegisteredAgentRunService()
	}
	return service.NewCraftSessionService(service.CraftSessionConfig{
		DB: db, Sessions: sessions, Store: store, Versions: versions,
		Runs: runs, ActiveRuns: service.CraftActiveRunsQuery(db),
		TemporaryDocs: documents, Files: files, Models: models,
		Access: access, TaskList: access,
		Gate: craftFeatureGateFromEnv(),
	})
}

// newCraftPreviewService assembles W02's preview service. Without a
// configured isolated https preview origin the feature stays disabled:
// issuance answers unavailable and the isolated origin 404s.
func newCraftPreviewService(
	versions craft.VersionStore,
	files interfaces.FileService,
	checks craft.PreviewCheckStore,
	access *service.CraftAccessService,
) *service.CraftPreviewService {
	return service.NewCraftPreviewService(versions, files, checks, service.CraftPreviewConfig{
		AppOrigin:     strings.TrimSpace(os.Getenv("WEKNORA_CRAFT_APP_ORIGIN")),
		PreviewOrigin: strings.TrimSpace(os.Getenv("WEKNORA_CRAFT_PREVIEW_ORIGIN")),
		AccessChecker: access,
	})
}

// newMobileVoiceHandler assembles the W30 mobile voice surface (fail-closed
// like the W26 craft precedent): the managed provider's server-held wiring
// (long-lived key, token/transcribe endpoints, media-proxy signing key) and
// the charged-voice price version come from the WEKNORA_VOICE_* environment
// references. None of it is required for boot — an unconfigured provider
// answers ErrProviderUnavailable on call and an unpriced voice plane refuses
// charged sessions, so the endpoints mount once and deny safely until the
// deployment configures them. The provider's long-lived key never leaves
// this process: token minting and transcription proxying both happen here.
func newMobileVoiceHandler(
	db *gorm.DB,
	gate domain.ExecutionGate,
) (*handler.MobileVoiceHandler, error) {
	provider, err := voice.NewManagedProvider(voice.Config{
		LongLivedAPIKey:    strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PROVIDER_API_KEY")),
		Model:              strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PROVIDER_MODEL")),
		TokenEndpoint:      strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PROVIDER_TOKEN_URL")),
		TranscribeEndpoint: strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PROVIDER_TRANSCRIBE_URL")),
		SigningKey:         strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PROXY_SIGNING_KEY")),
	})
	if err != nil {
		return nil, err
	}
	// The charged-voice admission source: the price version in force plus
	// its audio_seconds rate. The rate resolver itself belongs to the
	// commercial pricing administration (blocked-env); until one is wired
	// the admission fails closed — charged voice is refused, never priced
	// through a text dimension.
	rates := &handler.PriceVersionVoiceAdmission{
		Version: strings.TrimSpace(os.Getenv("WEKNORA_VOICE_PRICE_VERSION")),
	}
	return handler.NewMobileVoiceHandler(
		repository.NewVoiceSessionStore(db),
		repository.NewVoiceTranscriptionStore(db),
		provider,
		provider,
		gate,
		rates,
		repocommercial.NewBudgetStore(db),
	)
}

// newUsageRecorderService wires SP12's chat usage ingestion. Model rates come
// from the WEKNORA_USAGE_RATES environment variable; a malformed value logs a
// warning and yields empty rates (tokens recorded, cost zero) instead of
// failing startup — the chat path must not go down with the meter.
func newUsageRecorderService(repo interfaces.UsageRepository) interfaces.UsageRecorderService {
	rates, err := usage.RatesFromEnv(os.Getenv("WEKNORA_USAGE_RATES"))
	if err != nil {
		logger.Warnf(context.Background(), "[Container] usage: %v; recording chat usage without pricing", err)
		rates = usage.ModelRates{}
	}
	return service.NewUsageRecorderService(repo, rates)
}

// newCraftKnowledgeService assembles C01's knowledge material build onto
// the EXISTING ACL entrances — BindCraftKnowledgeAccess over the real
// knowledgeService.GetKnowledgeBatchWithSharedAccess and
// BindCraftKnowledgeSearch over the real knowledgeBaseService.HybridSearch —
// plus the R02 craft store. The workspace writer targets the local craft
// runtime's serve working directory: knowledge/ stages beside inputs/ and
// output/ in that tree, exactly where the pinned OpenCode serve session
// resolves the workspace-relative paths the material manifest names. Without
// the real runtime dial (CRAFT_OPENCODE_BASE_URL unset) the provider answers
// a nil service — fail-closed, like the executor and snapshot service.
func newCraftKnowledgeService(
	store craft.Store,
	knowledge interfaces.KnowledgeService,
	knowledgeBases interfaces.KnowledgeBaseService,
	executor craft.Executor,
) (*service.CraftKnowledgeService, error) {
	runtime, ok := executor.(*localCraftRuntime)
	if !ok {
		return nil, nil
	}
	workDir := runtime.workDir
	writer := func(ctx context.Context, workspace craft.Workspace, path string, content []byte) error {
		// Workspace-relative staging paths only: the build hands its own
		// canonical knowledge/... constants through this seam, and anything
		// that is not exactly one canonical relative path is refused rather
		// than resolved against the serve working directory.
		if path == "" || path != pathCleanForward(path) ||
			strings.HasPrefix(path, "/") || strings.Contains(path, "..") {
			return fmt.Errorf("craft: refusing non-canonical knowledge staging path %q", path)
		}
		target := filepath.Join(workDir, filepath.FromSlash(path))
		if err := os.MkdirAll(filepath.Dir(target), 0o755); err != nil {
			return err
		}
		return os.WriteFile(target, content, 0o644)
	}
	return service.NewCraftKnowledgeService(service.CraftKnowledgeConfig{
		Store:  store,
		Access: service.BindCraftKnowledgeAccess(knowledge),
		Search: service.BindCraftKnowledgeSearch(knowledgeBases),
		Writer: writer,
	})
}

type craftRunViewAdmittedRunReader interface {
	Get(context.Context, agentruntime.RunKey) (agentruntime.Run, error)
}

// CraftRunViewProductionAssembly is the server-owned RunView dependency set
// offered to downstream Craft assembly. An unavailable assembly is a normal
// default-off state; callers must treat nil Provider/ResolveMaterial as a
// hard refusal and must never substitute the legacy local work directory.
type CraftRunViewProductionAssembly struct {
	Provider           *CraftRunViewContainerProvider
	RuntimeCoordinator *CraftRunViewRuntimeCoordinator
	Store              craft.RunViewStore
	ResolveMaterial    func(context.Context, craft.Task) (CraftRunViewMaterialHandle, error)
	Close              func() error
	Unavailable        string
}

const (
	craftRunViewImageBinarySHA256 = "3557e87db8c7db70e8ebd42157df1246554120896b115c462b760ff248cf751e"
)

// craftRunViewProductionConfigFromEnv reads only explicit server deployment
// pins. In particular, it does not infer an image digest from a local image
// ID or from Docker's RepoDigests.
func craftRunViewProductionConfigFromEnv() (CraftRunViewContainerProviderConfig, string, bool) {
	config := CraftRunViewContainerProviderConfig{
		SandboxRoot:          strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_SANDBOX_ROOT")),
		ImageReference:       strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_IMAGE_REFERENCE")),
		ImageDigest:          strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_IMAGE_DIGEST")),
		OpenCodeBinarySHA256: craftRunViewImageBinarySHA256,
		RuntimeConfigSHA256:  strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_RUNTIME_CONFIG_SHA256")),
		OpenCodeVersion:      craftRunViewOpenCodeVersion,
		ProjectID:            strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_PROJECT_ID")),
	}
	endpoint := strings.TrimSpace(os.Getenv("CRAFT_RUNVIEW_DOCKER_ENDPOINT"))
	complete := config.SandboxRoot != "" && config.ImageReference != "" && config.ImageDigest != "" &&
		config.RuntimeConfigSHA256 != "" && config.ProjectID != "" && endpoint != ""
	return config, endpoint, complete
}

func provideCraftRunViewProductionAssembly(db *gorm.DB, runs *repository.AgentRunStore) *CraftRunViewProductionAssembly {
	config, endpoint, complete := craftRunViewProductionConfigFromEnv()
	if !complete {
		return &CraftRunViewProductionAssembly{Unavailable: "RunView production pins are incomplete"}
	}
	engine, err := NewCraftRunViewDockerEngine(endpoint)
	if err != nil {
		return &CraftRunViewProductionAssembly{Unavailable: fmt.Sprintf("RunView Docker engine unavailable: %v", err)}
	}
	assembly, err := assembleCraftRunViewProduction(config, repository.NewCraftRunViewStore(db), runs, engine)
	if err != nil {
		_ = engine.Close()
		return &CraftRunViewProductionAssembly{Unavailable: fmt.Sprintf("RunView provider unavailable: %v", err)}
	}
	assembly.Close = engine.Close
	return assembly
}

// assembleCraftRunViewProduction is the testable constructor behind the
// production DI provider. Its resolver verifies the current durable Run and
// writer slot before the coordinator can allocate a generation or create a
// container/session.
func assembleCraftRunViewProduction(
	config CraftRunViewContainerProviderConfig,
	store craft.RunViewStore,
	runs craftRunViewAdmittedRunReader,
	engine CraftRunViewContainerEngine,
) (*CraftRunViewProductionAssembly, error) {
	return assembleCraftRunViewProductionWithAPI(config, store, runs, engine, newCraftRunViewSessionAPI)
}

func assembleCraftRunViewProductionWithAPI(
	config CraftRunViewContainerProviderConfig,
	store craft.RunViewStore,
	runs craftRunViewAdmittedRunReader,
	engine CraftRunViewContainerEngine,
	apiFactory craftRunViewSessionAPIFactory,
) (*CraftRunViewProductionAssembly, error) {
	if store == nil || runs == nil {
		return nil, unresolvedCraftRunView("RunView store or durable Run reader is missing", nil)
	}
	provider, err := newCraftRunViewContainerProvider(config, engine, apiFactory)
	if err != nil {
		return nil, err
	}
	coordinator, err := NewCraftRunViewRuntimeCoordinator(store, provider, "/workspace")
	if err != nil {
		return nil, err
	}
	assembly := &CraftRunViewProductionAssembly{
		Provider: provider, RuntimeCoordinator: coordinator, Store: store,
	}
	assembly.ResolveMaterial = func(ctx context.Context, task craft.Task) (CraftRunViewMaterialHandle, error) {
		if err := ctx.Err(); err != nil {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("material resolution canceled", err)
		}
		if task.Fence.TenantID == 0 || task.Fence.TenantID != task.Scope.TenantID ||
			task.Scope.UserID == "" || task.Scope.SessionID == "" || task.WorkspaceID == "" ||
			task.Fence.RunID == "" || task.Fence.Owner == "" || task.Fence.Epoch < 1 {
			return CraftRunViewMaterialHandle{}, fmt.Errorf("%w: incomplete admitted Craft Task fence", craft.ErrForbidden)
		}
		key := craft.RunViewKey{TenantID: task.Scope.TenantID, OwnerID: task.Scope.UserID, SessionID: task.Scope.SessionID, RunID: task.Fence.RunID}
		if err := craft.ValidateRunViewKey(key); err != nil {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("admitted Run identity is invalid", err)
		}
		run, err := runs.Get(ctx, agentruntime.RunKey{TenantID: task.Scope.TenantID, RunID: task.Fence.RunID})
		if err != nil {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("load durable admitted Run", err)
		}
		caller := types.CallerFromContext(ctx)
		if run.Key != (agentruntime.RunKey{TenantID: task.Scope.TenantID, RunID: task.Fence.RunID}) ||
			run.UserID != task.Scope.UserID || run.SessionID != task.Scope.SessionID ||
			run.ActorUserID == "" || caller.TenantID != run.Key.TenantID || caller.UserID != run.ActorUserID ||
			run.Status != "running" || run.Owner == "" || run.Owner != task.Fence.Owner ||
			run.Epoch < 1 || run.Epoch != task.Fence.Epoch || !run.LeaseUntil.After(time.Now()) {
			return CraftRunViewMaterialHandle{}, fmt.Errorf("%w: durable admitted Run actor or writer fence changed", craft.ErrConflict)
		}
		snapshot, err := service.ParseDurableRunSnapshot(run.Snapshot)
		if err != nil || snapshot.CraftWorkspaceSeed == nil || snapshot.CraftWorkspaceSeed.WorkspaceID != task.WorkspaceID {
			return CraftRunViewMaterialHandle{}, fmt.Errorf("%w: durable Run snapshot does not authorize this Workspace", craft.ErrConflict)
		}
		if err := ctx.Err(); err != nil {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("material resolution canceled after Run verification", err)
		}
		runtime, err := coordinator.Resolve(ctx, key)
		if err != nil {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("resolve admitted RunView runtime", err)
		}
		if runtime.View.Key != key || runtime.View.State != craft.RunViewStateBound {
			return CraftRunViewMaterialHandle{}, unresolvedCraftRunView("admitted RunView is not bound to this task", nil)
		}
		return provider.MaterialHandle(ctx, store, key, runtime)
	}
	return assembly, nil
}

// validateCraftKnowledgeAssembly constructs the craft knowledge build at
// boot so a missing port fails fast instead of surfacing at first use. A
// nil service is the recorded fail-closed state (no runtime dial), not an
// error.
func validateCraftKnowledgeAssembly(knowledge *service.CraftKnowledgeService) {
	if knowledge == nil {
		logger.Infof(context.Background(), "[CraftKnowledge] build not assembled: the craft runtime dial is not configured")
		return
	}
	logger.Infof(context.Background(), "[CraftKnowledge] build assembled with the production ACL entrances")
}

// wireCraftInteractionRegistrar installs the C02 interaction.pending
// registrar onto the local craft runtime once both sides exist. This is
// the deliberate break of the provider cycle executor → interaction
// assembly → agent runtime → executor that panicked boot at Provide time
// on the merged integration HEAD (verified pre-existing before this
// change): the executor no longer takes the assembly as a constructor
// parameter, and this invoke lands the same wiring after construction,
// before any delegation can execute.
func wireCraftInteractionRegistrar(executor craft.Executor, assembly *CraftInteractionAssembly) {
	runtime, ok := executor.(*localCraftRuntime)
	if !ok || assembly == nil {
		return
	}
	// BASE wrapped the executor's emission path with the registrar at
	// construction using the executor's OWN opencode client; the
	// post-construction install reuses that same client (assembly.Client
	// may legitimately be nil when its own dial failed).
	runtime.setInteractionEmitter(craftInteractionRegistrar(
		runtime.client, runtime.store, assembly.Store, assembly.Runs, runtime.emit))
}

// registerCraftHTTPHandlers installs the craft handlers for route mounting.
// The session service itself is the registered API surface; routes_chat.go
// wraps it in the HTTP handler at mounting time.
func registerCraftHTTPHandlers(svc *service.CraftSessionService, previews *service.CraftPreviewService, snapshots *service.CraftSnapshotService) {
	session.RegisterCraftSessionHandler(svc)
	session.RegisterCraftPreviewRouteHandler(session.NewCraftPreviewHandler(previews))
	if snapshots != nil {
		session.RegisterCraftSnapshotHandler(snapshots)
	}
}

// newCraftScheduledService assembles SP3's scheduled-task application service
// (editor-mode cron compilation, owner-scoped CRUD, run-now and the run
// history page) over the owner-scoped store.
func newCraftScheduledService(store repository.CraftScheduledTaskRepository) (*service.CraftScheduledService, error) {
	return service.NewCraftScheduledService(store)
}

// registerCraftScheduledHTTPHandlers installs the SP3 scheduled-task service
// as the registered API surface; routes_chat.go wraps it in the HTTP handler
// at mounting time (the craft sessions shape) and mounts
// /craft/scheduled-tasks only when this ran (fail-closed, no 503 shims).
func registerCraftScheduledHTTPHandlers(svc *service.CraftScheduledService) {
	session.RegisterCraftScheduledHandler(svc)
}

// registerArtifactVersionHTTPHandlers installs the W26 immutable artifact
// version download handler for route mounting. The store scopes every read
// to (tenant, session, ready version); routes_chat.go mounts the route only
// when this registration ran (fail-closed).
func registerArtifactVersionHTTPHandlers(
	sessions interfaces.SessionService,
	tenants interfaces.TenantService,
	files interfaces.FileService,
	storage interfaces.StorageBackendResolver,
	versions *repository.ArtifactVersionStore,
) {
	session.RegisterArtifactVersionDownloadHandler(session.NewArtifactVersionDownloadHandler(sessions, tenants, files, storage, versions))
}

// registerArtifactPreviewHTTPHandlers installs the W27 isolated artifact
// preview handler for route mounting. Issuance re-runs the W26
// (tenant, session, ready-version) authorization; the preview origin itself
// is ticket-only. The version store is the same provider the versioned
// downloads consume; the isolated origin comes from the handler's own env
// configuration and stays disabled (fail-closed) when unset.
func registerArtifactPreviewHTTPHandlers(
	sessions interfaces.SessionService,
	tenants interfaces.TenantService,
	files interfaces.FileService,
	storage interfaces.StorageBackendResolver,
	versions *repository.ArtifactVersionStore,
) {
	handler.RegisterArtifactPreviewHandler(handler.NewArtifactPreviewHandler(sessions, tenants, files, storage, versions))
}
