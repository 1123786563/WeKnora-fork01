package service

import (
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	"github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/tools"
	"github.com/Tencent/WeKnora/internal/modules/craft"
	"github.com/Tencent/WeKnora/internal/types"
	"github.com/stretchr/testify/require"
)

func TestDurableCraftKnowledgeSelectionSnapshotRoundTrip(t *testing.T) {
	query := "Use sales Q1 and explain the regional trend."
	modelQuery := query + "\n\n[已授权输入材料]\n- uploads/sales.csv"
	config := &types.AgentConfig{AllowedTools: []string{tools.ToolThinking}}
	inputs := []craft.Input{{Ref: "resource://upload-1", Name: "sales.csv", SHA256: strings.Repeat("a", 64), Bytes: 12}}
	selection := CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-selected"}}

	raw, err := BuildDurableCraftRunSnapshotWithKnowledgeSelection(modelQuery, nil, "model-1", "", config, inputs, selection)
	require.NoError(t, err)
	require.JSONEq(t, `{"query":"Use sales Q1 and explain the regional trend.","knowledge_base_ids":["kb-selected"]}`, selectionJSONFromSnapshot(t, raw))
	parsed, err := ParseDurableRunSnapshot(raw)
	require.NoError(t, err)
	require.Equal(t, modelQuery, parsed.Query, "the model prompt retains server-composed input guidance")
	require.NotNil(t, parsed.CraftKnowledgeSelection)
	require.Equal(t, query, parsed.CraftKnowledgeSelection.Query)
	require.Equal(t, []string{"kb-selected"}, parsed.CraftKnowledgeSelection.KnowledgeBaseIDs)
	require.NotNil(t, parsed.CraftInputManifest)
	require.Equal(t, inputs, *parsed.CraftInputManifest)

	message, err := durableUserMessage(parsed)
	require.NoError(t, err)
	require.Equal(t, modelQuery, message.Content, "the model receives the exact admitted prompt, without snapshot selection expansion")
	require.NotContains(t, message.Content, "kb-selected")

	reordered, err := BuildDurableCraftRunSnapshotWithKnowledgeSelection(modelQuery, nil, "model-1", "", config, inputs,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-selected"}})
	require.NoError(t, err)
	reorderedAgain, err := BuildDurableCraftRunSnapshotWithKnowledgeSelection(modelQuery, nil, "model-1", "", config, inputs,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-selected"}})
	require.NoError(t, err)
	require.Equal(t, reordered, reorderedAgain, "the one-KB selection produces stable snapshot bytes for the durable request digest")
}

func TestDurableCraftKnowledgeSelectionCompatibilityAndGenericSnapshot(t *testing.T) {
	config := &types.AgentConfig{AllowedTools: []string{tools.ToolThinking}}
	craftRaw, err := BuildDurableCraftRunSnapshot("legacy craft prompt", nil, "model-1", "", config, []craft.Input{})
	require.NoError(t, err)
	legacyCraftRaw := rewriteCraftKnowledgeSelection(t, craftRaw, nil, false)
	legacyCraft, err := ParseDurableRunSnapshot(legacyCraftRaw)
	require.NoError(t, err)
	require.NotNil(t, legacyCraft.CraftKnowledgeSelection, "legacy Craft snapshot without the field is explicit empty selection")
	require.Equal(t, "legacy craft prompt", legacyCraft.CraftKnowledgeSelection.Query)
	require.NotNil(t, legacyCraft.CraftKnowledgeSelection.KnowledgeBaseIDs)
	require.Empty(t, legacyCraft.CraftKnowledgeSelection.KnowledgeBaseIDs)

	newCraft, err := ParseDurableRunSnapshot(craftRaw)
	require.NoError(t, err)
	require.NotNil(t, newCraft.CraftKnowledgeSelection, "new Craft snapshots encode empty selection explicitly")
	require.Empty(t, newCraft.CraftKnowledgeSelection.KnowledgeBaseIDs, "empty means no selected KB, never all KBs")

	genericRaw, err := BuildDurableRunSnapshot("generic prompt", nil, "model-1", "", config)
	require.NoError(t, err)
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(genericRaw, &fields))
	require.NotContains(t, fields, "craft_knowledge_selection", "generic snapshot JSON contract stays unchanged")
	generic, err := ParseDurableRunSnapshot(genericRaw)
	require.NoError(t, err)
	require.Nil(t, generic.CraftKnowledgeSelection)
}

func TestDurableCraftKnowledgeSelectionRejectsMalformedSelection(t *testing.T) {
	query := "sales"
	config := &types.AgentConfig{AllowedTools: []string{tools.ToolThinking}}
	valid, err := BuildDurableCraftRunSnapshotWithKnowledgeSelection(query, nil, "model-1", "", config, nil,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-a"}})
	require.NoError(t, err)
	tooMany := make([]string, craft.MaxKnowledgeSources+1)
	for i := range tooMany {
		tooMany[i] = fmt.Sprintf("kb-%02d", i)
	}
	for _, tc := range []struct {
		name  string
		value any
	}{
		{name: "null selection", value: nil},
		{name: "malformed object", value: []string{"kb-a"}},
		{name: "null id list", value: map[string]any{"query": query, "knowledge_base_ids": nil}},
		{name: "duplicate ids", value: map[string]any{"query": query, "knowledge_base_ids": []string{"kb-a", "kb-a"}}},
		{name: "two KBs exceed current selection contract", value: map[string]any{"query": query, "knowledge_base_ids": []string{"kb-a", "kb-b"}}},
		{name: "oversized selection", value: map[string]any{"query": query, "knowledge_base_ids": tooMany}},
		{name: "empty retrieval query", value: map[string]any{"query": "", "knowledge_base_ids": []string{"kb-a"}}},
		{name: "oversized retrieval query", value: map[string]any{"query": strings.Repeat("q", MaxCraftPromptBytes+1), "knowledge_base_ids": []string{"kb-a"}}},
		{name: "empty id", value: map[string]any{"query": query, "knowledge_base_ids": []string{" "}}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			_, err := ParseDurableRunSnapshot(rewriteCraftKnowledgeSelection(t, valid, tc.value, true))
			require.Error(t, err)
		})
	}

	_, err = BuildDurableCraftRunSnapshotWithKnowledgeSelection(query, nil, "model-1", "", config, nil,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-a", "kb-a"}})
	require.Error(t, err, "the builder rejects duplicate IDs before persistence")
	_, err = BuildDurableCraftRunSnapshotWithKnowledgeSelection(query, nil, "model-1", "", config, nil,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: []string{"kb-a", "kb-b"}})
	require.ErrorIs(t, err, craft.ErrInvalidInput, "the builder rejects two selected KBs under the current zero-or-one contract")
	_, err = BuildDurableCraftRunSnapshotWithKnowledgeSelection(query, nil, "model-1", "", config, nil,
		CraftKnowledgeSelectionSnapshot{Query: query, KnowledgeBaseIDs: tooMany})
	require.Error(t, err, "the builder rejects oversized selections before persistence")
}

func selectionJSONFromSnapshot(t *testing.T, raw json.RawMessage) string {
	t.Helper()
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(raw, &fields))
	selection, ok := fields["craft_knowledge_selection"]
	require.True(t, ok, "Craft selection is persisted in the immutable snapshot")
	return string(selection)
}

func rewriteCraftKnowledgeSelection(t *testing.T, raw json.RawMessage, value any, present bool) json.RawMessage {
	t.Helper()
	var fields map[string]json.RawMessage
	require.NoError(t, json.Unmarshal(raw, &fields))
	if !present {
		delete(fields, "craft_knowledge_selection")
	} else {
		encoded, err := json.Marshal(value)
		require.NoError(t, err)
		fields["craft_knowledge_selection"] = encoded
	}
	rewritten, err := json.Marshal(fields)
	require.NoError(t, err)
	return rewritten
}
