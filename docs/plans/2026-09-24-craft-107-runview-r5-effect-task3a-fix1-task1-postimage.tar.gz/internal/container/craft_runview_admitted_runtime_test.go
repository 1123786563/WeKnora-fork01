package container

import (
	"context"
	"errors"
	"testing"
	"time"

	"github.com/Tencent/WeKnora/internal/modules/agentruntime/agent/runtime"
	"github.com/Tencent/WeKnora/internal/modules/craft"
	"github.com/stretchr/testify/require"
)

type admittedRuntimeAuthorityFake struct {
	view        craft.RunView
	allocateErr error
	stateful    bool
	issued      map[craft.RunViewEffectKind]bool
	beginErr    map[craft.RunViewEffectKind]error
	maySend     map[craft.RunViewEffectKind]bool
	outcomes    map[craft.RunViewEffectKind]craft.RunViewEffectOutcome
	allocTasks  []craft.Task
	beginTasks  []craft.Task
	claims      []craft.RunViewEffectClaim
	finished    []craft.RunViewEffectOutcome
	order       *[]string
	afterBegin  func(craft.RunViewEffectKind)
}

func (a *admittedRuntimeAuthorityFake) AllocateAdmitted(_ context.Context, task craft.Task) (craft.RunView, error) {
	a.allocTasks = append(a.allocTasks, task)
	if a.allocateErr != nil {
		return craft.RunView{}, a.allocateErr
	}
	if a.order != nil {
		*a.order = append(*a.order, "allocate")
	}
	return a.view, nil
}

func (a *admittedRuntimeAuthorityFake) BeginEffect(_ context.Context, task craft.Task, generation string, kind craft.RunViewEffectKind) (craft.RunViewEffectClaim, bool, error) {
	a.beginTasks = append(a.beginTasks, task)
	if a.order != nil {
		*a.order = append(*a.order, "claim:"+string(kind))
	}
	if err := a.beginErr[kind]; err != nil {
		return craft.RunViewEffectClaim{}, false, err
	}
	claim := craft.RunViewEffectClaim{Key: admittedRunViewKey(task), Generation: generation, Kind: kind, Token: "opaque-" + string(kind)}
	a.claims = append(a.claims, claim)
	maySend := a.maySend[kind]
	if a.stateful {
		if a.issued == nil {
			a.issued = map[craft.RunViewEffectKind]bool{}
		}
		maySend = !a.issued[kind]
		a.issued[kind] = true
	}
	if a.afterBegin != nil {
		a.afterBegin(kind)
	}
	return claim, maySend, nil
}

func (a *admittedRuntimeAuthorityFake) FinishEffect(_ context.Context, claim craft.RunViewEffectClaim, outcome craft.RunViewEffectOutcome) error {
	if a.order != nil {
		*a.order = append(*a.order, "finish:"+string(claim.Kind))
	}
	a.finished = append(a.finished, outcome)
	if prior, ok := a.outcomes[claim.Kind]; ok && prior != outcome {
		return craft.ErrConflict
	}
	a.outcomes[claim.Kind] = outcome
	return nil
}

type admittedRuntimeStoreFake struct {
	view       craft.RunView
	beginErr   error
	beginCalls int
}

func (s *admittedRuntimeStoreFake) Allocate(context.Context, craft.RunViewKey) (craft.RunView, error) {
	return craft.RunView{}, errors.New("legacy Allocate must not be called")
}
func (s *admittedRuntimeStoreFake) Load(_ context.Context, key craft.RunViewKey) (craft.RunView, error) {
	if s.view.Key != key {
		return craft.RunView{}, craft.ErrConflict
	}
	return s.view, nil
}
func (s *admittedRuntimeStoreFake) BeginSessionCreate(_ context.Context, key craft.RunViewKey, generation string) (craft.RunView, bool, error) {
	s.beginCalls++
	if s.beginErr != nil {
		return craft.RunView{}, false, s.beginErr
	}
	if s.view.Key != key || s.view.Generation != generation {
		return craft.RunView{}, false, craft.ErrConflict
	}
	maySend := s.view.SessionCreateIntentAt == nil && s.view.State == craft.RunViewStateAllocating
	if maySend {
		now := time.Now().UTC()
		s.view.SessionCreateIntentAt = &now
	}
	return s.view, maySend, nil
}
func (s *admittedRuntimeStoreFake) BindRuntime(_ context.Context, key craft.RunViewKey, generation string, runtime craft.RunViewRuntime) (craft.RunView, error) {
	if s.view.Key != key || s.view.Generation != generation {
		return craft.RunView{}, craft.ErrConflict
	}
	s.view.State, s.view.Runtime = craft.RunViewStateBound, runtime
	return s.view, nil
}

type admittedLegacyOnlyProvider struct{ CraftRunViewRuntimeProvider }

type admittedRuntimeProviderFake struct {
	container           CraftRunViewRuntimeContainer
	exists              bool
	running             bool
	sessions            []CraftRunViewRuntimeSession
	createErr           error
	createMutations     int
	startErr            error
	sessionErr          error
	observeContainerErr error
	observeStateErr     error
	calls               []string
	order               *[]string
	createEntered       chan struct{}
	createRelease       <-chan struct{}
}

func (p *admittedRuntimeProviderFake) add(call string) {
	p.calls = append(p.calls, call)
	if p.order != nil {
		*p.order = append(*p.order, "provider:"+call)
	}
}
func (p *admittedRuntimeProviderFake) InspectOrCreateContainer(context.Context, CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, error) {
	p.add("legacy-inspect-or-create")
	return p.container, nil
}
func (p *admittedRuntimeProviderFake) FindSessions(context.Context, CraftRunViewRuntimeContainer) (CraftRunViewRuntimeInventory, error) {
	p.add("find-sessions")
	return CraftRunViewRuntimeInventory{Authoritative: true, Complete: true, Directory: p.container.Directory, ProjectID: p.container.ProjectID, Sessions: append([]CraftRunViewRuntimeSession(nil), p.sessions...)}, nil
}
func (p *admittedRuntimeProviderFake) ObserveSessions(ctx context.Context, container CraftRunViewRuntimeContainer) (CraftRunViewRuntimeInventory, error) {
	p.add("observe-sessions")
	return CraftRunViewRuntimeInventory{Authoritative: true, Complete: true, Directory: container.Directory, ProjectID: container.ProjectID, Sessions: append([]CraftRunViewRuntimeSession(nil), p.sessions...)}, nil
}
func (p *admittedRuntimeProviderFake) CreateSession(context.Context, CraftRunViewRuntimeContainer, string) error {
	p.add("create-session")
	if p.sessionErr != nil {
		return p.sessionErr
	}
	p.sessions = []CraftRunViewRuntimeSession{{ID: "session-1", ProjectID: p.container.ProjectID, Directory: p.container.Directory}}
	return nil
}
func (p *admittedRuntimeProviderFake) CreateOpenCodeSession(ctx context.Context, container CraftRunViewRuntimeContainer, directory string) error {
	return p.CreateSession(ctx, container, directory)
}
func (p *admittedRuntimeProviderFake) ObserveContainer(_ context.Context, spec CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, bool, error) {
	p.add("observe-container")
	if p.observeContainerErr != nil {
		return CraftRunViewRuntimeContainer{}, false, p.observeContainerErr
	}
	p.container.Generation, p.container.RuntimeID, p.container.ContainerID, p.container.Directory = spec.Generation, spec.RuntimeID, spec.ContainerID, spec.Directory
	return p.container, p.exists, nil
}
func (p *admittedRuntimeProviderFake) CreateGenerationContainer(ctx context.Context, spec CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, error) {
	p.add("create-container")
	if p.createEntered != nil {
		close(p.createEntered)
		<-p.createRelease
	}
	if p.createErr != nil {
		return CraftRunViewRuntimeContainer{}, p.createErr
	}
	if err := ctx.Err(); err != nil {
		return CraftRunViewRuntimeContainer{}, err
	}
	p.createMutations++
	p.exists = true
	p.container.Generation, p.container.RuntimeID, p.container.ContainerID, p.container.Directory = spec.Generation, spec.RuntimeID, spec.ContainerID, spec.Directory
	return p.container, nil
}
func (p *admittedRuntimeProviderFake) ObserveContainerState(_ context.Context, container CraftRunViewRuntimeContainer) (CraftRunViewRuntimeContainer, bool, error) {
	p.add("observe-container-state")
	if p.observeStateErr != nil {
		return CraftRunViewRuntimeContainer{}, false, p.observeStateErr
	}
	p.container = container
	return p.container, p.running, nil
}
func (p *admittedRuntimeProviderFake) StartGenerationContainer(context.Context, CraftRunViewRuntimeContainer) (CraftRunViewRuntimeContainer, error) {
	p.add("start-container")
	if p.startErr != nil {
		return CraftRunViewRuntimeContainer{}, p.startErr
	}
	p.running = true
	return p.container, nil
}

type admittedSplitRuntimeProvider interface {
	ObserveContainer(context.Context, CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, bool, error)
	CreateGenerationContainer(context.Context, CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, error)
	ObserveContainerState(context.Context, CraftRunViewRuntimeContainer) (CraftRunViewRuntimeContainer, bool, error)
	StartGenerationContainer(context.Context, CraftRunViewRuntimeContainer) (CraftRunViewRuntimeContainer, error)
}

func admittedRunViewKey(task craft.Task) craft.RunViewKey {
	return craft.RunViewKey{TenantID: task.Scope.TenantID, OwnerID: task.Scope.UserID, SessionID: task.Scope.SessionID, RunID: task.Fence.RunID}
}
func admittedTask() craft.Task {
	const digest = "sha256:0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef"
	fence := runtime.Fence{RunKey: runtime.RunKey{TenantID: 8, RunID: "run-1"}, Owner: "writer-1", Epoch: 3, SnapshotDigestVersion: 1, SnapshotDigest: digest}
	return craft.Task{Scope: craft.Scope{TenantID: 8, UserID: "owner-1", SessionID: "session-main"}, Fence: fence, SnapshotDigestVersion: 1, SnapshotDigest: digest, WorkspaceID: "workspace-1"}
}
func admittedView(task craft.Task) craft.RunView {
	return craft.RunView{Key: admittedRunViewKey(task), Generation: "generation-1", State: craft.RunViewStateAllocating}
}
func admittedProvider() *admittedRuntimeProviderFake {
	return &admittedRuntimeProviderFake{exists: false, container: CraftRunViewRuntimeContainer{Generation: "generation-1", RuntimeID: "runtime-1", ContainerID: "container-1", Directory: "/srv/craft/view-1", ProjectID: "project-1", IdentityVerified: true, DedicatedForRun: true, DirectoryCanonical: true}}
}
func admittedCoordinator(t *testing.T, task craft.Task, authority *admittedRuntimeAuthorityFake, provider CraftRunViewRuntimeProvider, store *admittedRuntimeStoreFake) *CraftRunViewRuntimeCoordinator {
	t.Helper()
	coordinator, err := NewCraftRunViewAdmittedRuntimeCoordinator(store, authority, provider, "/srv/craft")
	require.NoError(t, err)
	return coordinator
}

func TestCraftRunViewAdmittedCoordinatorRequiresSplitMutationProvider(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task)}
	provider := admittedProvider()
	store := &admittedRuntimeStoreFake{view: authority.view}
	coordinator := admittedCoordinator(t, task, authority, admittedLegacyOnlyProvider{CraftRunViewRuntimeProvider: provider}, store)
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Len(t, authority.allocTasks, 1)
	require.Empty(t, authority.claims)
	require.Empty(t, provider.calls, "combined InspectOrCreateContainer cannot be safely claimed as separate Docker create/start effects")
}

func TestCraftRunViewAdmittedCoordinatorClaimsEachMutationBeforeCall(t *testing.T) {
	task := admittedTask()
	order := []string{}
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), maySend: map[craft.RunViewEffectKind]bool{craft.RunViewEffectDockerCreate: true, craft.RunViewEffectDockerStart: true, craft.RunViewEffectOpenCodeCreate: true}, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}, order: &order}
	provider := admittedProvider()
	provider.order = &order
	store := &admittedRuntimeStoreFake{view: authority.view}
	coordinator := admittedCoordinator(t, task, authority, provider, store)
	handle, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	require.Equal(t, craft.RunViewStateBound, handle.View.State)
	require.Equal(t, "session-1", handle.View.Runtime.OpenCodeSessionID)
	require.Equal(t, []craft.RunViewEffectKind{craft.RunViewEffectDockerCreate, craft.RunViewEffectDockerStart, craft.RunViewEffectOpenCodeCreate}, []craft.RunViewEffectKind{authority.claims[0].Kind, authority.claims[1].Kind, authority.claims[2].Kind})
	require.Len(t, authority.finished, 3)
	require.Equal(t, task, authority.allocTasks[0], "allocation receives the original admitted Task")
	for _, claimedTask := range authority.beginTasks {
		require.Equal(t, task, claimedTask, "each effect claim reuses the original Task fence and digest")
	}
	require.Equal(t, craft.RunViewEffectOutcome{State: craft.RunViewEffectStateSucceeded, Receipt: handle.View.Runtime.ContainerID}, authority.finished[0])
	require.Equal(t, craft.RunViewEffectOutcome{State: craft.RunViewEffectStateSucceeded, Receipt: handle.View.Runtime.ContainerID + "|running"}, authority.finished[1])
	require.Equal(t, craft.RunViewEffectOutcome{State: craft.RunViewEffectStateSucceeded, Receipt: "session-1"}, authority.finished[2])
	for _, kind := range []craft.RunViewEffectKind{craft.RunViewEffectDockerCreate, craft.RunViewEffectDockerStart, craft.RunViewEffectOpenCodeCreate} {
		claimAt, providerAt := -1, -1
		for i, item := range order {
			if item == "claim:"+string(kind) {
				claimAt = i
			}
			if item == "provider:create-container" && kind == craft.RunViewEffectDockerCreate {
				providerAt = i
			}
			if item == "provider:start-container" && kind == craft.RunViewEffectDockerStart {
				providerAt = i
			}
			if item == "provider:create-session" && kind == craft.RunViewEffectOpenCodeCreate {
				providerAt = i
			}
		}
		require.NotEqual(t, -1, claimAt)
		require.NotEqual(t, -1, providerAt)
		require.Less(t, claimAt, providerAt, "claim %s precedes provider call", kind)
	}
}

func TestCraftRunViewAdmittedClaimDenialAndUnknownNeverResend(t *testing.T) {
	t.Run("transition-first", func(t *testing.T) {
		task := admittedTask()
		authority := &admittedRuntimeAuthorityFake{view: admittedView(task), beginErr: map[craft.RunViewEffectKind]error{craft.RunViewEffectDockerCreate: runtime.ErrLeaseLost}}
		provider := admittedProvider()
		store := &admittedRuntimeStoreFake{view: authority.view}
		coordinator := admittedCoordinator(t, task, authority, provider, store)
		_, err := coordinator.ResolveAdmitted(context.Background(), task)
		require.ErrorIs(t, err, runtime.ErrLeaseLost)
		require.Zero(t, countCall(provider.calls, "create-container"))
		require.Zero(t, countCall(provider.calls, "start-container"))
		require.Zero(t, countCall(provider.calls, "create-session"))
	})
	t.Run("unknown-create-replay", func(t *testing.T) {
		task := admittedTask()
		authority := &admittedRuntimeAuthorityFake{view: admittedView(task), maySend: map[craft.RunViewEffectKind]bool{craft.RunViewEffectDockerCreate: true}, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}}
		provider := admittedProvider()
		provider.createErr = errors.New("connection reset after send")
		store := &admittedRuntimeStoreFake{view: authority.view}
		coordinator := admittedCoordinator(t, task, authority, provider, store)
		_, err := coordinator.ResolveAdmitted(context.Background(), task)
		require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
		require.Equal(t, 1, countCall(provider.calls, "create-container"))
		provider.createErr = nil
		authority.maySend[craft.RunViewEffectDockerCreate] = false
		_, err = coordinator.ResolveAdmitted(context.Background(), task)
		require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
		require.Equal(t, 1, countCall(provider.calls, "create-container"), "unknown create is observed but never sent again")
	})
}
func countCall(calls []string, want string) int {
	n := 0
	for _, call := range calls {
		if call == want {
			n++
		}
	}
	return n
}

func TestCraftRunViewAdmittedReplayKeepsGenerationAndNeverResends(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{
		view: admittedView(task),
		maySend: map[craft.RunViewEffectKind]bool{
			craft.RunViewEffectDockerCreate:   true,
			craft.RunViewEffectDockerStart:    true,
			craft.RunViewEffectOpenCodeCreate: true,
		},
		outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{},
	}
	provider := admittedProvider()
	store := &admittedRuntimeStoreFake{view: authority.view}
	coordinator := admittedCoordinator(t, task, authority, provider, store)
	first, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	createCount, startCount, sessionCount := countCall(provider.calls, "create-container"), countCall(provider.calls, "start-container"), countCall(provider.calls, "create-session")
	require.Equal(t, 1, createCount)
	require.Equal(t, 1, startCount)
	require.Equal(t, 1, sessionCount)

	for kind := range authority.maySend {
		authority.maySend[kind] = false
	}
	second, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	require.Equal(t, first.View.Generation, second.View.Generation, "admitted replay keeps the original generation")
	require.Equal(t, createCount, countCall(provider.calls, "create-container"))
	require.Equal(t, startCount, countCall(provider.calls, "start-container"))
	require.Equal(t, sessionCount, countCall(provider.calls, "create-session"))
}

func TestCraftRunViewAdmittedRejectsMutatedOriginalTaskFenceBeforeAllocation(t *testing.T) {
	task := admittedTask()
	task.Fence.SnapshotDigest = "sha256:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task)}
	provider := admittedProvider()
	store := &admittedRuntimeStoreFake{view: authority.view}
	coordinator := admittedCoordinator(t, task, authority, provider, store)
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Empty(t, authority.allocTasks, "an inconsistent Task fence cannot allocate a view")
	require.Empty(t, provider.calls)
}

func TestCraftRunViewAdmittedUnknownAtEveryProviderStageNeverResends(t *testing.T) {
	stages := []struct {
		name string
		kind craft.RunViewEffectKind
		fail func(*admittedRuntimeProviderFake)
		call string
	}{
		{name: "docker create", kind: craft.RunViewEffectDockerCreate, fail: func(p *admittedRuntimeProviderFake) { p.createErr = errors.New("lost create response") }, call: "create-container"},
		{name: "docker start", kind: craft.RunViewEffectDockerStart, fail: func(p *admittedRuntimeProviderFake) { p.startErr = errors.New("lost start response") }, call: "start-container"},
		{name: "opencode create", kind: craft.RunViewEffectOpenCodeCreate, fail: func(p *admittedRuntimeProviderFake) { p.sessionErr = errors.New("lost session response") }, call: "create-session"},
	}
	for _, stage := range stages {
		t.Run(stage.name, func(t *testing.T) {
			task := admittedTask()
			authority := &admittedRuntimeAuthorityFake{
				view: admittedView(task),
				maySend: map[craft.RunViewEffectKind]bool{
					craft.RunViewEffectDockerCreate:   true,
					craft.RunViewEffectDockerStart:    true,
					craft.RunViewEffectOpenCodeCreate: true,
				},
				outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{},
			}
			provider := admittedProvider()
			stage.fail(provider)
			store := &admittedRuntimeStoreFake{view: authority.view}
			coordinator := admittedCoordinator(t, task, authority, provider, store)
			_, err := coordinator.ResolveAdmitted(context.Background(), task)
			require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
			require.Equal(t, 1, countCall(provider.calls, stage.call), "the claimed provider operation is sent once")
			require.Equal(t, craft.RunViewEffectStateUnknown, authority.outcomes[stage.kind].State)

			for kind := range authority.maySend {
				authority.maySend[kind] = false
			}
			stage.fail(provider)
			_, err = coordinator.ResolveAdmitted(context.Background(), task)
			require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
			require.Equal(t, 1, countCall(provider.calls, stage.call), "unknown operations are observed but never resent")
		})
	}
}

func TestCraftRunViewAdmittedChangedContainerReceiptStaysUnknown(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{
		view:     admittedView(task),
		maySend:  map[craft.RunViewEffectKind]bool{craft.RunViewEffectDockerCreate: true},
		outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{},
	}
	provider := admittedProvider()
	provider.exists = true
	provider.container.IdentityVerified = false
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Empty(t, authority.claims, "an unclaimed wrong identity cannot be recorded as an unknown send")
	require.Empty(t, authority.outcomes)
	require.Zero(t, countCall(provider.calls, "create-container"))
	require.Zero(t, countCall(provider.calls, "start-container"))
	require.Zero(t, countCall(provider.calls, "create-session"))
}

func TestCraftRunViewAdmittedCancellationAfterClaimRecordsUnknownWithoutSend(t *testing.T) {
	task := admittedTask()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	authority := &admittedRuntimeAuthorityFake{
		view:     admittedView(task),
		maySend:  map[craft.RunViewEffectKind]bool{craft.RunViewEffectDockerCreate: true},
		outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{},
		afterBegin: func(kind craft.RunViewEffectKind) {
			if kind == craft.RunViewEffectDockerCreate {
				cancel()
			}
		},
	}
	provider := admittedProvider()
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(ctx, task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Equal(t, craft.RunViewEffectStateUnknown, authority.outcomes[craft.RunViewEffectDockerCreate].State)
	require.Equal(t, 1, countCall(provider.calls, "create-container"), "the claimed operation receives the canceled context")
	require.Zero(t, provider.createMutations, "provider cancellation stops before the fake side effect")
}

func TestCraftRunViewAdmittedClaimFirstBarrierExposesIntentBeforeProviderSend(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{
		view:     admittedView(task),
		maySend:  map[craft.RunViewEffectKind]bool{craft.RunViewEffectDockerCreate: true},
		outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{},
	}
	provider := admittedProvider()
	provider.createEntered = make(chan struct{})
	release := make(chan struct{})
	provider.createRelease = release
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	result := make(chan error, 1)
	go func() { _, err := coordinator.ResolveAdmitted(context.Background(), task); result <- err }()
	select {
	case <-provider.createEntered:
	case <-time.After(5 * time.Second):
		t.Fatal("provider did not reach the claimed create stage")
	}
	require.Len(t, authority.claims, 1)
	require.Equal(t, craft.RunViewEffectDockerCreate, authority.claims[0].Kind)
	require.Equal(t, admittedRunViewKey(task), authority.claims[0].Key)
	require.Equal(t, "generation-1", authority.claims[0].Generation)
	close(release)
	require.ErrorIs(t, <-result, ErrCraftRunViewRuntimeUnresolved)
}

func TestCraftRunViewAdmittedStaleRunFailsBeforeProvider(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), allocateErr: runtime.ErrLeaseLost}
	// AllocateAdmitted is the first live Run/fence check in the real authority.
	// A stale writer must fail there without allowing the coordinator to call a provider.
	provider := admittedProvider()
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, runtime.ErrLeaseLost)
	require.Empty(t, provider.calls)
}

func TestCraftRunViewAdmittedPreclaimContainerObservationFailureCanRetry(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), stateful: true, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}}
	provider := admittedProvider()
	provider.observeContainerErr = errors.New("temporary inspect failure")
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Empty(t, authority.claims, "a read-only failure occurs before a send claim")
	require.Empty(t, authority.outcomes)
	require.Zero(t, countCall(provider.calls, "create-container"))

	provider.observeContainerErr = nil
	_, err = coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err, "the exact generation can be retried after a pre-send read failure")
	require.Equal(t, 1, countEffectClaim(authority.claims, craft.RunViewEffectDockerCreate))
	require.Equal(t, 1, countCall(provider.calls, "create-container"))
}

func TestCraftRunViewAdmittedWrongPreclaimContainerIdentityCanRetry(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), stateful: true, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}}
	provider := admittedProvider()
	provider.exists = true
	provider.container.IdentityVerified = false
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Empty(t, authority.claims, "identity mismatch is a failed observation, not a provider send")
	require.Empty(t, authority.outcomes)

	provider.exists = false
	provider.container.IdentityVerified = true
	_, err = coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	require.Equal(t, 1, countEffectClaim(authority.claims, craft.RunViewEffectDockerCreate))
	require.Equal(t, 1, countCall(provider.calls, "create-container"))
}

func TestCraftRunViewAdmittedPreclaimStateObservationFailureCanRetry(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), stateful: true, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}}
	provider := admittedProvider()
	provider.observeStateErr = errors.New("temporary state inspection failure")
	coordinator := admittedCoordinator(t, task, authority, provider, &admittedRuntimeStoreFake{view: authority.view})
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Zero(t, countEffectClaim(authority.claims, craft.RunViewEffectDockerStart), "start is not claimed until its read-only state observation succeeds")
	require.Empty(t, authority.outcomes[craft.RunViewEffectDockerStart])
	require.Zero(t, countCall(provider.calls, "start-container"))

	provider.observeStateErr = nil
	_, err = coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	require.Equal(t, 1, countEffectClaim(authority.claims, craft.RunViewEffectDockerStart))
	require.Equal(t, 1, countCall(provider.calls, "start-container"))
}

func TestCraftRunViewAdmittedSessionMarkerFailureDoesNotClaimOpenCodeEffect(t *testing.T) {
	task := admittedTask()
	authority := &admittedRuntimeAuthorityFake{view: admittedView(task), stateful: true, outcomes: map[craft.RunViewEffectKind]craft.RunViewEffectOutcome{}}
	provider := admittedProvider()
	store := &admittedRuntimeStoreFake{view: authority.view, beginErr: errors.New("temporary marker write failure")}
	coordinator := admittedCoordinator(t, task, authority, provider, store)
	_, err := coordinator.ResolveAdmitted(context.Background(), task)
	require.ErrorIs(t, err, ErrCraftRunViewRuntimeUnresolved)
	require.Zero(t, countEffectClaim(authority.claims, craft.RunViewEffectOpenCodeCreate), "DB-only marker failure must not consume the provider claim")
	require.Empty(t, authority.outcomes[craft.RunViewEffectOpenCodeCreate])
	require.Zero(t, countCall(provider.calls, "create-session"))

	store.beginErr = nil
	_, err = coordinator.ResolveAdmitted(context.Background(), task)
	require.NoError(t, err)
	require.Equal(t, 1, countEffectClaim(authority.claims, craft.RunViewEffectOpenCodeCreate))
	require.Equal(t, 1, countCall(provider.calls, "create-session"))
}

func countEffectClaim(claims []craft.RunViewEffectClaim, kind craft.RunViewEffectKind) int {
	count := 0
	for _, claim := range claims {
		if claim.Kind == kind {
			count++
		}
	}
	return count
}
