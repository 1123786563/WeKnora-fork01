package service

import (
	"context"
	"errors"
	"testing"
	"time"

	repository "github.com/Tencent/WeKnora/internal/application/repository"
	"github.com/Tencent/WeKnora/internal/modules/commercial"
	"github.com/Tencent/WeKnora/internal/modules/execution/sandbox"
	"github.com/stretchr/testify/require"
)

type fakeOutputlessDocker struct {
	createCalls        int
	startCalls         int
	startErr           error
	observation        sandbox.DockerOutputlessExecObservation
	observations       []sandbox.DockerOutputlessExecObservation
	observeCalls       int
	observeErr         error
	receipts           []sandbox.DockerOutputlessExecReceipt
	runningSeen        []bool
	observeEntered     chan struct{}
	observeRelease     chan struct{}
	observeDone        <-chan struct{}
	blockOnObserveCall int
}

func (f *fakeOutputlessDocker) CreateOutputlessExec(context.Context, sandbox.RemoteSandboxHandle, sandbox.DockerOutputlessExecRequest) (sandbox.DockerOutputlessExecReceipt, error) {
	f.createCalls++
	return sandbox.DockerOutputlessExecReceipt{ContainerID: "container-fake", ExecID: "exec-fake"}, nil
}
func (f *fakeOutputlessDocker) StartOutputlessExec(context.Context, sandbox.DockerOutputlessExecReceipt, time.Duration) error {
	f.startCalls++
	return f.startErr
}
func (f *fakeOutputlessDocker) ObserveOutputlessExec(ctx context.Context, receipt sandbox.DockerOutputlessExecReceipt, running bool) (sandbox.DockerOutputlessExecObservation, error) {
	f.observeCalls++
	f.receipts = append(f.receipts, receipt)
	f.runningSeen = append(f.runningSeen, running)
	if f.observeEntered != nil && f.observeCalls == f.blockOnObserveCall {
		f.observeDone = ctx.Done()
		close(f.observeEntered)
		<-f.observeRelease // deliberately ignore cancellation to model an inspect that returns late
	}
	if f.observeErr != nil {
		return sandbox.DockerOutputlessExecObservation{State: sandbox.DockerOutputlessUnknown}, f.observeErr
	}
	if len(f.observations) > 0 {
		index := f.observeCalls - 1
		if index >= len(f.observations) {
			index = len(f.observations) - 1
		}
		return f.observations[index], nil
	}
	return f.observation, nil
}

type fakeDockerHandle struct{}

func (fakeDockerHandle) ID() string                       { return "container-fake" }
func (fakeDockerHandle) Provider() sandbox.RemoteProvider { return sandbox.SandboxTypeDocker }
func (fakeDockerHandle) Metadata() map[string]string      { return nil }

func TestCraftDockerRestrictedRejectsUnsupportedContractBeforeHold(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	service, err := NewCraftDockerRestrictedExec(coordinator, &sandbox.DockerRemoteClient{}, 0)
	require.NoError(t, err)
	callback := func(string, []byte) {}
	for _, request := range []CraftDockerOutputlessRequest{
		{Exec: sandbox.RemoteExecRequest{Command: "true"}},
		{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true", Stdin: "input"}},
		{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true", OnOutput: callback}},
	} {
		_, err := service.Start(context.Background(), grantID, "activity-rejected", CraftCallBinding{}, nil, request)
		require.Error(t, err)
	}
	var rows int64
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-rejected").Count(&rows).Error)
	require.Zero(t, rows, "unsupported output contracts are rejected before any durable hold")
}

func TestCraftDockerRestrictedPhysicalStartRequiresExclusiveDurableClaim(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	request := CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}}
	binding := CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}
	result, err := service.Start(context.Background(), grantID, "activity-one-send", binding, fakeDockerHandle{}, request)
	require.NoError(t, err)
	require.True(t, result.Accepted)
	require.False(t, result.StdoutAvailable)
	require.False(t, result.StderrAvailable)
	require.Equal(t, 1, docker.createCalls)
	require.Equal(t, 1, docker.startCalls)
	_, err = service.ResumeBound(context.Background(), grantID, "activity-one-send")
	require.Error(t, err, "claimed receipt cannot be resumed into another physical start")
	require.Equal(t, 1, docker.startCalls)
	var claimed int64
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Where("tenant_id = ? AND activity_key = ? AND send_claimed_at IS NOT NULL", tenant, "activity-one-send").Count(&claimed).Error)
	require.EqualValues(t, 1, claimed)
}

func TestCraftDockerRestrictedLostStartResponseStaysUnknownWithoutRetry(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{startErr: errors.New("connection lost after daemon acceptance")}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	request := CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}}
	result, err := service.Start(context.Background(), grantID, "activity-lost-response", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, request)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.False(t, result.StdoutAvailable)
	_, resumeErr := service.ResumeBound(context.Background(), grantID, "activity-lost-response")
	require.Error(t, resumeErr)
	require.Equal(t, 1, docker.startCalls)
	var row struct {
		State         string
		SendClaimedAt *time.Time
	}
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("state, send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-lost-response").Take(&row).Error)
	require.Equal(t, "intent", row.State)
	require.NotNil(t, row.SendClaimedAt)
}

type boundaryCanceledContext struct{ context.Context }

// The context becomes observably canceled at the claim boundary while keeping
// its Done channel open during the database call. This isolates the fence
// between a successful durable Claim and provider start.
func (boundaryCanceledContext) Err() error { return context.Canceled }

func TestCraftDockerRestrictedCancellationAfterClaimSkipsProviderStart(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	ctx := boundaryCanceledContext{Context: context.Background()}
	result, err := service.Start(ctx, grantID, "activity-cancel-after-claim", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.ErrorIs(t, err, context.Canceled)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.False(t, result.Accepted)
	require.Equal(t, 1, docker.createCalls)
	require.Zero(t, docker.startCalls, "canceled context must be fenced after durable claim and before provider start")
	var row struct {
		State         string
		SendClaimedAt *time.Time
	}
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("state, send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-cancel-after-claim").Take(&row).Error)
	require.Equal(t, "intent", row.State)
	require.NotNil(t, row.SendClaimedAt, "claim remains durable and must not be released")
}

func TestCraftDockerRestrictedWaitReturnsOutputlessTerminalState(t *testing.T) {
	coordinator, _, _, _, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observations: []sandbox.DockerOutputlessExecObservation{
		{State: sandbox.DockerOutputlessRunning},
		{State: sandbox.DockerOutputlessRunning},
		{State: sandbox.DockerOutputlessSucceeded, ExitCode: ptr(0)},
	}}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	result, err := service.Start(context.Background(), grantID, "activity-wait-terminal", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.NoError(t, err)
	terminal, err := service.Wait(context.Background(), grantID, "activity-wait-terminal", time.Second)
	require.NoError(t, err)
	require.Equal(t, result.Receipt, terminal.Receipt)
	require.Equal(t, sandbox.DockerOutputlessSucceeded, terminal.State)
	require.NotNil(t, terminal.ExitCode)
	require.Equal(t, 0, *terminal.ExitCode)
	require.False(t, terminal.StdoutAvailable)
	require.False(t, terminal.StderrAvailable)
	require.False(t, terminal.DurationAvailable, "Docker exec inspect has no authoritative execution duration")
	require.Equal(t, 3, docker.observeCalls)
	for i, receipt := range docker.receipts {
		require.Equal(t, sandbox.DockerOutputlessExecReceipt{ContainerID: result.Receipt.ContainerID, ExecID: result.Receipt.ExecID}, receipt)
		if i > 0 {
			require.True(t, docker.runningSeen[i], "running provenance must carry forward for this exact receipt")
		}
	}
}

func TestCraftDockerRestrictedWaitCancellationRemainsUnknown(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observations: []sandbox.DockerOutputlessExecObservation{{State: sandbox.DockerOutputlessRunning}}}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	_, err = service.Start(context.Background(), grantID, "activity-wait-canceled", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.NoError(t, err)
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	result, err := service.Wait(ctx, grantID, "activity-wait-canceled", time.Second)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.Equal(t, sandbox.DockerOutputlessUnknown, result.State)
	require.False(t, result.StdoutAvailable)
	require.False(t, result.StderrAvailable)
	require.Zero(t, docker.observeCalls, "canceled wait must not start a poll")
	var row struct{ SendClaimedAt *time.Time }
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-wait-canceled").Take(&row).Error)
	require.NotNil(t, row.SendClaimedAt, "wait cancellation must preserve durable hold/claim")
}

func TestCraftDockerRestrictedWaitDeadlineRemainsUnknown(t *testing.T) {
	coordinator, _, _, _, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observations: []sandbox.DockerOutputlessExecObservation{{State: sandbox.DockerOutputlessRunning}}}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	_, err = service.Start(context.Background(), grantID, "activity-wait-deadline", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.NoError(t, err)
	result, err := service.Wait(context.Background(), grantID, "activity-wait-deadline", 15*time.Millisecond)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.Equal(t, sandbox.DockerOutputlessUnknown, result.State)
	require.False(t, result.DurationAvailable, "deadline does not provide execution duration")
}

func ptr[T any](value T) *T { return &value }

func TestCraftDockerRestrictedWaitInspectErrorRemainsUnknown(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observeErr: errors.New("inspect unavailable")}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	_, err = service.Start(context.Background(), grantID, "activity-wait-inspect-error", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.NoError(t, err)
	result, err := service.Wait(context.Background(), grantID, "activity-wait-inspect-error", time.Second)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.ErrorContains(t, err, "inspect unavailable")
	require.Equal(t, sandbox.DockerOutputlessUnknown, result.State)
	require.Equal(t, 1, docker.observeCalls)
	var row struct{ SendClaimedAt *time.Time }
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-wait-inspect-error").Take(&row).Error)
	require.NotNil(t, row.SendClaimedAt)
}

func TestCraftDockerRestrictedWaitReturnsFastTerminalState(t *testing.T) {
	coordinator, _, _, _, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observations: []sandbox.DockerOutputlessExecObservation{
		{State: sandbox.DockerOutputlessRunning},
		{State: sandbox.DockerOutputlessFailed, ExitCode: ptr(7)},
	}}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	_, err = service.Start(context.Background(), grantID, "activity-wait-fast", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "false"}})
	require.NoError(t, err)
	result, err := service.Wait(context.Background(), grantID, "activity-wait-fast", time.Second)
	require.NoError(t, err)
	require.Equal(t, sandbox.DockerOutputlessFailed, result.State)
	require.NotNil(t, result.ExitCode)
	require.Equal(t, 7, *result.ExitCode)
	require.False(t, result.DurationAvailable)
	require.False(t, result.StdoutAvailable)
	require.False(t, result.StderrAvailable)
}

func TestCraftDockerRestrictedWaitCancellationDuringInspectRejectsLateTerminal(t *testing.T) {
	for _, tc := range []struct {
		name     string
		state    sandbox.DockerOutputlessExecState
		exitCode int
		deadline bool
	}{
		{name: "late success after cancellation", state: sandbox.DockerOutputlessSucceeded, exitCode: 0},
		{name: "late failure after deadline", state: sandbox.DockerOutputlessFailed, exitCode: 23, deadline: true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
			docker := &fakeOutputlessDocker{
				observations: []sandbox.DockerOutputlessExecObservation{
					{State: sandbox.DockerOutputlessRunning},
					{State: tc.state, ExitCode: ptr(tc.exitCode)},
				},
				observeEntered:     make(chan struct{}),
				observeRelease:     make(chan struct{}),
				blockOnObserveCall: 2,
			}
			service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
			require.NoError(t, err)
			_, err = service.Start(context.Background(), grantID, "activity-late-terminal", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
			require.NoError(t, err)

			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			maxWait := time.Second
			if tc.deadline {
				maxWait = 100 * time.Millisecond
			}
			type waitResult struct {
				result CraftDockerOutputlessResult
				err    error
			}
			done := make(chan waitResult, 1)
			go func() {
				result, waitErr := service.Wait(ctx, grantID, "activity-late-terminal", maxWait)
				done <- waitResult{result: result, err: waitErr}
			}()
			<-docker.observeEntered
			require.NotNil(t, docker.observeDone)
			if tc.deadline {
				<-docker.observeDone
			} else {
				cancel()
				<-docker.observeDone
			}
			close(docker.observeRelease)
			got := <-done
			require.ErrorIs(t, got.err, sandbox.ErrRemoteOperationUnknown)
			require.Equal(t, sandbox.DockerOutputlessUnknown, got.result.State)
			require.Equal(t, repository.DockerExecReceipt{Provider: "docker", ContainerID: "container-fake", ExecID: "exec-fake"}, got.result.Receipt)
			require.False(t, got.result.StdoutAvailable)
			require.False(t, got.result.StderrAvailable)
			require.False(t, got.result.DurationAvailable)
			var row struct{ SendClaimedAt *time.Time }
			require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-late-terminal").Take(&row).Error)
			require.NotNil(t, row.SendClaimedAt, "late terminal must not release the durable claim")
		})
	}
}

func TestCraftDockerRestrictedWaitFirstFalseZeroRemainsUnknown(t *testing.T) {
	coordinator, budget, _, tenant, grantID := newCraftDockerCoordinatorFixture(t)
	docker := &fakeOutputlessDocker{observations: []sandbox.DockerOutputlessExecObservation{{State: sandbox.DockerOutputlessUnknown, ExitCode: ptr(0)}}}
	service, err := NewCraftDockerRestrictedExec(coordinator, docker, time.Second)
	require.NoError(t, err)
	_, err = service.Start(context.Background(), grantID, "activity-first-false-zero", CraftCallBinding{ModelID: "model", Funding: commercial.FundingPlatform}, fakeDockerHandle{}, CraftDockerOutputlessRequest{DiscardOutput: true, Exec: sandbox.RemoteExecRequest{Command: "true"}})
	require.NoError(t, err)
	result, err := service.Wait(context.Background(), grantID, "activity-first-false-zero", 45*time.Millisecond)
	require.ErrorIs(t, err, sandbox.ErrRemoteOperationUnknown)
	require.Equal(t, sandbox.DockerOutputlessUnknown, result.State)
	require.Nil(t, result.ExitCode, "false/zero without prior running provenance is not a terminal result")
	require.False(t, result.StdoutAvailable)
	require.False(t, result.StderrAvailable)
	require.GreaterOrEqual(t, docker.observeCalls, 1)
	require.False(t, docker.runningSeen[0], "the first inspect has no positive running provenance")
	var row struct{ SendClaimedAt *time.Time }
	require.NoError(t, budget.db.Table("craft_charge_start_journal").Select("send_claimed_at").Where("tenant_id = ? AND activity_key = ?", tenant, "activity-first-false-zero").Take(&row).Error)
	require.NotNil(t, row.SendClaimedAt)
}
