package container

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"path"
	"strings"
	"unicode"

	"github.com/Tencent/WeKnora/internal/modules/craft"
)

// ErrCraftRunViewRuntimeUnresolved means runtime creation or recovery cannot
// be proven safe. Callers must not dispatch a prompt while this error applies.
var ErrCraftRunViewRuntimeUnresolved = errors.New("craft RunView runtime unresolved")

// CraftRunViewRuntimeContainerSpec is a deterministic, server-derived
// identity for the one runtime container assigned to a RunView generation.
// Directory is inside that runtime, not a host path and never caller input.
type CraftRunViewRuntimeContainerSpec struct {
	Generation  string
	RuntimeID   string
	ContainerID string
	Directory   string
}

// CraftRunViewRuntimeContainer is the provider's observed identity for the
// generation-scoped container. A provider must implement
// InspectOrCreateContainer idempotently and must not replace a container for
// an existing generation after an uncertain result.
type CraftRunViewRuntimeContainer struct {
	Generation         string
	RuntimeID          string
	ContainerID        string
	Directory          string
	ProjectID          string
	IdentityVerified   bool
	DedicatedForRun    bool
	DirectoryCanonical bool
}

// CraftRunViewRuntimeSession is server-observed session metadata. Directory
// must be the OpenCode session's reported directory, not merely the request
// header that was sent during creation.
type CraftRunViewRuntimeSession struct {
	ID        string
	ProjectID string
	Directory string
}

// CraftRunViewRuntimeInventory is usable for recovery only when Authoritative
// is true, Directory and ProjectID match the inspected container, and Sessions
// contains the full cursor-paginated set for that exact OpenCode scope. A
// filtered, partial or unavailable inventory is not evidence.
type CraftRunViewRuntimeInventory struct {
	Authoritative bool
	Complete      bool
	Directory     string
	ProjectID     string
	Sessions      []CraftRunViewRuntimeSession
}

// CraftRunViewRuntimeProvider is the narrow boundary around the runtime
// provider. FindSessions must return every page from the pinned OpenCode
// GET /api/session endpoint scoped to the exact directory and project, with
// each Session.Info.location.directory and projectID preserved. It must not
// mark the inventory authoritative unless cursor pagination completed. The
// pinned source also defines GET /api/session/:sessionID for rechecking a
// selected session. These are upstream source routes, not routes verified in
// the checked-in legacy lock or a live binary. This interface is a contract
// only; it does not assert that any current provider implements it.
type CraftRunViewRuntimeProvider interface {
	InspectOrCreateContainer(context.Context, CraftRunViewRuntimeContainerSpec) (CraftRunViewRuntimeContainer, error)
	FindSessions(context.Context, CraftRunViewRuntimeContainer) (CraftRunViewRuntimeInventory, error)
	CreateSession(context.Context, CraftRunViewRuntimeContainer, string) error
}

// CraftRunViewRuntimeHandle is returned only after a persisted bound row has
// been reloaded and its runtime/session identity matched to authoritative
// provider evidence. It is an internal server-side handle, not an API DTO.
// Directory is the canonical in-container project directory for this view.
type CraftRunViewRuntimeHandle struct {
	View      craft.RunView
	Directory string
}

// CraftRunViewRuntimeCoordinator resolves one server-owned runtime generation
// to its unique verified OpenCode session. It is not wired into production
// assembly and does not itself establish OS-level isolation.
type CraftRunViewRuntimeCoordinator struct {
	store           craft.RunViewStore
	provider        CraftRunViewRuntimeProvider
	privateRootBase string
}

// NewCraftRunViewRuntimeCoordinator creates a coordinator using an absolute,
// canonical, server-configured base directory inside the provider runtime.
func NewCraftRunViewRuntimeCoordinator(
	store craft.RunViewStore,
	provider CraftRunViewRuntimeProvider,
	privateRootBase string,
) (*CraftRunViewRuntimeCoordinator, error) {
	if store == nil || provider == nil {
		return nil, fmt.Errorf("%w: missing store or provider", ErrCraftRunViewRuntimeUnresolved)
	}
	if !validCraftRunViewDirectory(privateRootBase) || privateRootBase == "/" {
		return nil, fmt.Errorf("%w: private root base must be a canonical absolute path below root", ErrCraftRunViewRuntimeUnresolved)
	}
	return &CraftRunViewRuntimeCoordinator{store: store, provider: provider, privateRootBase: privateRootBase}, nil
}

// Resolve allocates or loads the stable generation, deterministically resolves
// its container, observes session inventory, and binds only one session whose
// generation/container/directory metadata all match. BeginSessionCreate is the
// only path to a first CreateSession call. After an intent exists, resolution
// is observe-only; zero or ambiguous inventory stays unresolved.
func (c *CraftRunViewRuntimeCoordinator) Resolve(ctx context.Context, key craft.RunViewKey) (CraftRunViewRuntimeHandle, error) {
	view, err := c.store.Allocate(ctx, key)
	if err != nil {
		return CraftRunViewRuntimeHandle{}, err
	}
	if err := craft.ValidateRunView(view); err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("stored allocation is invalid", err)
	}
	if view.Key != key {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("stored allocation scope differs from admitted Run", nil)
	}

	spec := c.containerSpec(view.Generation)
	container, err := c.provider.InspectOrCreateContainer(ctx, spec)
	if err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("inspect or create generation container", err)
	}
	if container.Generation != spec.Generation || container.RuntimeID != spec.RuntimeID ||
		container.ContainerID != spec.ContainerID || container.Directory != spec.Directory ||
		!validCraftRunViewToken(container.ProjectID) ||
		!container.IdentityVerified || !container.DedicatedForRun || !container.DirectoryCanonical {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("provider container identity does not match generation", nil)
	}

	observed, err := c.observeSession(ctx, container)
	if err != nil {
		return CraftRunViewRuntimeHandle{}, err
	}
	if view.State == craft.RunViewStateBound {
		if observed == nil || view.Runtime != runtimeForSession(container, *observed) {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("bound runtime does not match unique observed session", nil)
		}
		return c.reloadBound(ctx, key, view.Generation, container, *observed)
	}

	if observed == nil {
		if view.SessionCreateIntentAt != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("session create was already attempted but no session is observable", nil)
		}
		intentView, maySend, err := c.store.BeginSessionCreate(ctx, key, view.Generation)
		if err != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("claim one-shot session-create intent", err)
		}
		if err := craft.ValidateRunView(intentView); err != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("stored create intent is invalid", err)
		}
		if intentView.Generation != view.Generation || intentView.Key != key {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("create intent changed generation or scope", nil)
		}
		if !maySend {
			return c.reconcileAfterLostCreatePermission(ctx, key, intentView, container)
		}
		if intentView.SessionCreateIntentAt == nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("store granted permission without durable intent", nil)
		}
		view = intentView
		if err := ctx.Err(); err != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("cancelled after durable create intent", err)
		}
		if err := c.provider.CreateSession(ctx, container, spec.Directory); err != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("CreateSession outcome is unknown", err)
		}
		observed, err = c.observeSession(ctx, container)
		if err != nil {
			return CraftRunViewRuntimeHandle{}, err
		}
		if observed == nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("CreateSession returned but no session is observable", nil)
		}
	}

	// Existing unique session evidence may be recovered without a new create,
	// but the durable marker is still required before BindRuntime.
	if view.SessionCreateIntentAt == nil {
		intentView, _, err := c.store.BeginSessionCreate(ctx, key, view.Generation)
		if err != nil {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("record intent before binding observed session", err)
		}
		view = intentView
	}
	return c.bindAndReload(ctx, key, view.Generation, container, *observed)
}

func (c *CraftRunViewRuntimeCoordinator) reconcileAfterLostCreatePermission(
	ctx context.Context,
	key craft.RunViewKey,
	view craft.RunView,
	container CraftRunViewRuntimeContainer,
) (CraftRunViewRuntimeHandle, error) {
	observed, err := c.observeSession(ctx, container)
	if err != nil {
		return CraftRunViewRuntimeHandle{}, err
	}
	if observed == nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("another caller owns or completed session creation but no session is observable", nil)
	}
	if view.State == craft.RunViewStateBound {
		if view.Runtime != runtimeForSession(container, *observed) {
			return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("concurrent binding differs from observed session", nil)
		}
		return c.reloadBound(ctx, key, view.Generation, container, *observed)
	}
	if view.SessionCreateIntentAt == nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("losing caller received no durable create intent", nil)
	}
	return c.bindAndReload(ctx, key, view.Generation, container, *observed)
}

func (c *CraftRunViewRuntimeCoordinator) observeSession(
	ctx context.Context,
	container CraftRunViewRuntimeContainer,
) (*CraftRunViewRuntimeSession, error) {
	inventory, err := c.provider.FindSessions(ctx, container)
	if err != nil {
		return nil, unresolvedCraftRunView("observe OpenCode sessions", err)
	}
	if !inventory.Authoritative || !inventory.Complete || inventory.Directory != container.Directory || inventory.ProjectID != container.ProjectID {
		return nil, unresolvedCraftRunView("provider session inventory is not complete and scoped to the inspected directory/project", nil)
	}
	if len(inventory.Sessions) > 1 {
		return nil, unresolvedCraftRunView("multiple sessions exist in the generation container", nil)
	}
	if len(inventory.Sessions) == 0 {
		return nil, nil
	}
	session := inventory.Sessions[0]
	if !validCraftRunViewToken(session.ID) || session.ProjectID != container.ProjectID ||
		session.Directory != container.Directory {
		return nil, unresolvedCraftRunView("session project/directory affinity is not proven", nil)
	}
	return &session, nil
}

func (c *CraftRunViewRuntimeCoordinator) bindAndReload(
	ctx context.Context,
	key craft.RunViewKey,
	generation string,
	container CraftRunViewRuntimeContainer,
	session CraftRunViewRuntimeSession,
) (CraftRunViewRuntimeHandle, error) {
	runtime := runtimeForSession(container, session)
	if err := craft.ValidateRunViewRuntime(runtime); err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("observed runtime identity is invalid", err)
	}
	if _, err := c.store.BindRuntime(ctx, key, generation, runtime); err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("bind verified runtime identity", err)
	}
	return c.reloadBound(ctx, key, generation, container, session)
}

func (c *CraftRunViewRuntimeCoordinator) reloadBound(
	ctx context.Context,
	key craft.RunViewKey,
	generation string,
	container CraftRunViewRuntimeContainer,
	session CraftRunViewRuntimeSession,
) (CraftRunViewRuntimeHandle, error) {
	view, err := c.store.Load(ctx, key)
	if err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("reload bound RunView", err)
	}
	if err := craft.ValidateRunView(view); err != nil {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("reloaded RunView is invalid", err)
	}
	if view.State != craft.RunViewStateBound || view.Generation != generation || view.Key != key ||
		view.Runtime != runtimeForSession(container, session) {
		return CraftRunViewRuntimeHandle{}, unresolvedCraftRunView("persisted runtime differs from provider evidence", nil)
	}
	return CraftRunViewRuntimeHandle{View: view, Directory: container.Directory}, nil
}

func (c *CraftRunViewRuntimeCoordinator) containerSpec(generation string) CraftRunViewRuntimeContainerSpec {
	digest := sha256.Sum256([]byte(generation))
	short := hex.EncodeToString(digest[:16])
	return CraftRunViewRuntimeContainerSpec{
		Generation:  generation,
		RuntimeID:   "rv-runtime-" + short,
		ContainerID: "rv-container-" + short,
		Directory:   path.Join(c.privateRootBase, "rv-"+short),
	}
}

func runtimeForSession(container CraftRunViewRuntimeContainer, session CraftRunViewRuntimeSession) craft.RunViewRuntime {
	return craft.RunViewRuntime{RuntimeID: container.RuntimeID, ContainerID: container.ContainerID, OpenCodeSessionID: session.ID}
}

func validCraftRunViewDirectory(value string) bool {
	return value != "" && path.IsAbs(value) && path.Clean(value) == value &&
		!strings.Contains(value, "\\") && !strings.ContainsRune(value, '\x00')
}

func validCraftRunViewToken(value string) bool {
	if value == "" || len(value) > 255 || strings.TrimSpace(value) != value || strings.ContainsAny(value, "/\\") {
		return false
	}
	for _, char := range value {
		if unicode.IsControl(char) {
			return false
		}
	}
	return true
}

func unresolvedCraftRunView(stage string, cause error) error {
	if cause == nil {
		return fmt.Errorf("%w: %s", ErrCraftRunViewRuntimeUnresolved, stage)
	}
	return fmt.Errorf("%w: %s: %v", ErrCraftRunViewRuntimeUnresolved, stage, cause)
}
