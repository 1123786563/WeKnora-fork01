package craft

import "context"

// RunViewEffectKind names one durable permission to mutate a RunView runtime.
// Allocation is recorded with the admitted Run transaction; provider effects
// are claimed separately immediately before dispatch.
type RunViewEffectKind string

const (
	RunViewEffectAllocate       RunViewEffectKind = "allocate"
	RunViewEffectDockerCreate   RunViewEffectKind = "docker_create"
	RunViewEffectDockerStart    RunViewEffectKind = "docker_start"
	RunViewEffectOpenCodeCreate RunViewEffectKind = "opencode_create"
)

// RunViewEffectClaim is an opaque capability minted by the server after the
// current Run fence and immutable admission identity have been checked.
// Callers must never construct or substitute Token values.
type RunViewEffectClaim struct {
	Key        RunViewKey
	Generation string
	Kind       RunViewEffectKind
	Token      string
}

// RunViewEffectOutcome records the observed result of one claimed effect.
// Unknown is durable and unresolved; it can never grant a replacement send.
type RunViewEffectOutcome struct {
	State   RunViewEffectState
	Receipt string
}

type RunViewEffectState string

const (
	RunViewEffectStatePending   RunViewEffectState = "pending"
	RunViewEffectStateSucceeded RunViewEffectState = "succeeded"
	RunViewEffectStateFailed    RunViewEffectState = "failed"
	RunViewEffectStateUnknown   RunViewEffectState = "unknown"
)

// RunViewEffectAuthority is the server-owned writer authority for RunView
// allocation and mutating runtime effects. It consumes the original admitted
// Task, including its independent snapshot digest and Run Fence. The legacy
// RunViewStore.Allocate key-only method is not an effect authorization.
type RunViewEffectAuthority interface {
	AllocateAdmitted(context.Context, Task) (RunView, error)
	BeginEffect(context.Context, Task, string, RunViewEffectKind) (RunViewEffectClaim, bool, error)
	FinishEffect(context.Context, RunViewEffectClaim, RunViewEffectOutcome) error
}
